
AppMenuPage.controller("ctrlAppPage", function ($scope, $http, $filter, conFig) {
    $('#divLoading').hide();
    //  scroll  table header freezer 
    $scope.handleScroll = function () {
        const tableContainer = angular.element(document.querySelector('#table-container'));
        const thead = angular.element(document.querySelector('thead'));

        if (tableContainer && thead) {
            const containerRect = tableContainer[0].getBoundingClientRect();
            const containerTop = containerRect.top;
            const containerBottom = containerRect.bottom;

            const tableRect = thead[0].getBoundingClientRect();
            const tableTop = tableRect.top;
            const tableBottom = tableRect.bottom;

            if (containerTop > tableTop || containerBottom < tableBottom) {
                thead.addClass('sticky');
            } else {
                thead.removeClass('sticky');
            }
        }
    };

    //var url_ws = "https://localhost:7098/api/";
    var url_ws = conFig.service_api_url();
    //https://localhost:7098/api/Login/check_authorization


    function apply() {
        try {
            if ($scope.$root.$$phase != '$apply' && $scope.$root.$$phase != '$digest') {
                $scope.$apply();
            }
        } catch { }
    };

    function arr_def() {
        //alert(conFig.controller_action_befor());


        //AutoComplete
        $scope.autoText = {};
        $scope.filteredItems = {};

        $scope.selectViewTypeFollowup = true;
        $scope.action_part = 1;
        $scope.user_name = conFig.user_name();

        $scope.data_all = [];

        $scope.master_apu = [];
        $scope.master_bussiness_unit = [];
        $scope.master_unit_no = [];
        $scope.master_functional = [];
        $scope.master_ram = [];
        $scope.master_ram_level = [];
        $scope.master_ram_like = [];
        $scope.master_guidwords = [];

        $scope.data_results = [];
        $scope.data_conditions = [];

        $scope.select_history_tracking_record = false;
        $scope.selectedDataRamType = null;

        $scope.employeelist = [];

        // ล้างช่องข้อมูลหลังจากเพิ่มข้อความ
        $scope.employee_id = '';
        $scope.employee_name = '';
        $scope.employee_displayname = '';
        $scope.employee_email = '';
        $scope.employee_type = 'Contract';
        $scope.employee_img = 'assets/img/team/avatar.webp'

        $scope.searchdata = '';
        $scope.searchEmployee = '';

        $scope.tabChangeID = '1';

        $scope.flow_role_type = conFig.role_type();//admin,request,responder,approver
        $scope.flow_status = 0;

        $scope.exportfile = [{ DownloadPath: '', Name: '' }];
    }
    function replace_hashKey_arr(_arr) {
        var json = JSON.stringify(_arr, function (key, value) {
            if (key === "$$hashKey") {
                return undefined;
            }
            return value;
        });
        return json;
    }
    function page_load() {
        $scope.searchBySeq = false;
        arr_def();
        get_data(true, false);
    }
    function get_data(page_load, type_clear) {
        var user_name = $scope.user_name;
        var token_doc = '';

        var sub_software = '';
        var type_doc = 'create';
        try {
            sub_software = $scope.data_conditions[0].pha_sub_software;
        } catch { }

        $.ajax({
            url: url_ws + "Flow/load_page_search_details",
            data: '{"sub_software":"' + sub_software + '","user_name":"' + user_name + '","token_doc":"' + token_doc + '","type_doc":"' + type_doc + '"}',
            type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
            beforeSend: function () {
                if (page_load == false) {
                    //$('#divLoading').hide(); 
                }
                $('#divLoading').show();
            },
            complete: function () {
                if (page_load == false) {
                    //$('#divLoading').hide(); 
                }
                $('#divLoading').hide();
            },
            success: function (data) {
                var arr = data;
                console.log(arr);

                setTimeout(function () { var v = 0; }, 10000);

                if (page_load) {
                    $scope.data_all = arr;
                    $scope.master_apu = arr.apu;
                    $scope.master_business_unit = arr.business_unit;
                    $scope.master_unit_no = arr.unit_no;
                    $scope.master_functional = arr.functional;
                    $scope.master_functional_audition = arr.functional;//ใช้ใน functional audition 
                    $scope.master_ram = arr.ram;
                    $scope.master_ram_level = arr.ram_level;
                    $scope.master_guidwords = arr.guidwords;

                    $scope.employeelist = arr.employee;
                    $scope.master_approver = arr.employee;

                    $scope.master_apu = JSON.parse(replace_hashKey_arr(arr.apu));
                    $scope.master_unit_no = JSON.parse(replace_hashKey_arr(arr.unit_no));

                    try {
                        $scope.master_company = JSON.parse(replace_hashKey_arr(arr.company));
                        $scope.master_toc = JSON.parse(replace_hashKey_arr(arr.toc));
                        $scope.master_tagid = JSON.parse(replace_hashKey_arr(arr.tagid));

                    } catch { }
                }

                var iNoNew = 1;
                for (let i = 0; i < arr.results.length; i++) {
                    arr.results[i].no = (iNoNew);
                    iNoNew++;
                };

                $scope.data_results_def = arr.results;
                $scope.data_results = arr.results;

                $scope.data_conditions = arr.conditions;
                if ($scope.data_conditions[0].pha_sub_software == null) {
                    $scope.data_conditions[0].pha_sub_software = sub_software.toUpperCase();
                    $scope.data_conditions[0].expense_type = 'OPEX';
                    $scope.data_conditions[0].id_apu = null;
                    $scope.data_conditions[0].approver_user_name = null;
                }
                angular.copy($scope.data_conditions, $scope.data_conditions_def);

                //แสดงปุ่ม 
                $scope.cancle_type = true;
                $scope.export_type = false;
                $scope.submit_type = true;
                $scope.search_type = true;
                $scope.clear_type = true;

                $scope.master_unit_no_show = $filter('filter')($scope.master_unit_no, function (item) { return (item.id_apu == $scope.master_apu[0].id); });

                if ($scope.data_conditions[0].master_apu == null || $scope.data_conditions[0].master_apu == '') {
                    $scope.data_conditions[0].master_apu = null;
                    var arr_clone_def = { id: $scope.data_conditions[0].master_apu, name: 'Please select' };
                    $scope.master_apu.splice(0, 0, arr_clone_def);
                }
                if ($scope.data_conditions[0].master_functional == null || $scope.data_conditions[0].master_functional == '') {
                    $scope.data_conditions[0].master_functional = null;
                    var arr_clone_def = { id: $scope.data_conditions[0].master_functional, name: 'Please select' };
                    $scope.master_functional.splice(0, 0, arr_clone_def);
                }
                if ($scope.data_conditions[0].id_business_unit == null) {
                    $scope.data_conditions[0].id_business_unit = null;
                    var arr_clone_def = { id: $scope.data_conditions[0].id_business_unit, name: 'Please select' };
                    $scope.master_business_unit.splice(0, 0, arr_clone_def);
                }
                if ($scope.data_conditions[0].master_unit_no == null || $scope.data_conditions[0].master_unit_no == '') {
                    $scope.data_conditions[0].master_unit_no = null;
                    var arr_clone_def = { id: $scope.data_conditions[0].master_unit_no, name: 'Please select' };
                    $scope.master_unit_no.splice(0, 0, arr_clone_def);
                }
                if ($scope.master_approver[0].employee_name == null || $scope.master_approver[0].employee_name == '') {
                    $scope.master_approver[0].employee_name = null;
                    var arr_clone_def = { id: $scope.master_approver[0].employee_name, name: 'Please select' };
                    $scope.master_approver.splice(0, 0, arr_clone_def);
                }

                apply();
                console.log($scope);
                try {
                    const choicesapu = new Choices('.js-choice-apu');
                    const choicesfunc = new Choices('.js-choice-functional');
                    const choicesbu = new Choices('.js-choice-business_unit');
                    const choicesunit = new Choices('.js-choice-unit_no');
                    const choicesapprover = new Choices('.js-choice-approver');


                    const choices0 = new Choices('.js-choice-company');
                    const choices1 = new Choices('.js-choice-apu-jsea');
                    const choices2 = new Choices('.js-choice-toc');
                    const choices3 = new Choices('.js-choice-unit_no-jsea');
                    const choices4 = new Choices('.js-choice-tagid');
                    //const choices5 = new Choices('.js-choice-tagid_audition');
                } catch { }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    alert('Internal error: ' + jqXHR.responseText);
                } else {
                    alert('Unexpected ' + textStatus);
                }
            }

        });

    }
    $scope.SubSoftwateChange = function () {
        get_data(true, false);
    }
    $scope.tabChange = function (tab_id) {
        $scope.tabChangeID = tab_id;
    }
    $scope.selectDetails = function (item) {

        var controller_text = item.pha_sub_software;

        conFig.pha_seq = item.seq;
        conFig.pha_type_doc = 'edit';

        //alert(conFig.pha_seq);
    }
    $scope.selectDoc = function (item) {

        var controller_text = item.pha_sub_software;

        conFig.pha_seq = item.seq;
        conFig.pha_type_doc = 'edit';
        conFig.pha_status = item.pha_status;
        conFig.pha_sub_software = item.pha_sub_software;

        next_page(controller_text, conFig.pha_status);
    }
    $scope.actionChange = function (item) {

        var arr_search =
            $filter('filter')($scope.data_results_def, function (_item) {

                return (
                    (item.pha_sub_software == null ? 'x' : _item.pha_sub_software).toLowerCase() == (item.pha_sub_software == null ? 'x' : item.pha_sub_software).toLowerCase()
                    && (item.expense_type == null ? 'x' : _item.expense_type).toLowerCase() == (item.expense_type == null ? 'x' : item.expense_type).toLowerCase()
                    && (item.sub_expense_type == null ? 'x' : _item.sub_expense_type) == (item.sub_expense_type == null ? 'x' : item.sub_expense_type)
                    && (item.reference_moc == null ? 'x' : _item.reference_moc).includes((item.reference_moc == null ? 'x' : item.reference_moc))
                    && (item.project_no == null ? 'x' : _item.pha_no).includes((item.project_no == null ? 'x' : item.project_no))
                    && (item.pha_request_name == null ? 'x' : _item.pha_request_name).includes((item.pha_request_name == null ? 'x' : item.pha_request_name))
                    && (item.id_apu == null ? true : _item.id_apu == item.id_apu)
                    && (item.expense_type == 'CAPEX' && item.sub_expense_type == 'Normal' ?
                        (item.approver_user_name == null ? 'x' : _item.approver_user_name)
                        == (item.approver_user_name == null ? 'x' : item.approver_user_name) : true)
                );
            });
        $scope.data_results = arr_search;
        apply();
    }
    $scope.confirmCancle = function () {
        var page = 'home/Portal';
        window.open(page, "_top")
    }
    $scope.confirmClear = function () {
        get_data(false, true);
    }
    $scope.confirmSearch = function () {

        get_data(true, false);
    }
    function next_page(controller_text, pha_status) {
        controller_text = controller_text.toLowerCase();

        $.ajax({
            url: controller_text + "/next_page",
            data: '{"pha_seq":"' + conFig.pha_seq + '","pha_seq":"' + conFig.pha_seq + '","pha_type_doc":"' + conFig.pha_type_doc + '"'
                + ',"pha_sub_software":"' + controller_text + '","pha_status":"' + pha_status + '"}',
            type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
            beforeSend: function () {
                //$('#divLoading').show(); 
                $('#divLoading').show();
            },
            complete: function () {
                //$('#divLoading').hide(); 

                $('#divLoading').hide();
            },
            success: function (data) {
                var arr = data;
                window.open(data.page, "_top");
            },
            error: function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    alert('Internal error: ' + jqXHR.responseText);
                } else {
                    alert('Unexpected ' + textStatus);
                }
            }

        });
    }

    //search list function
    $scope.autoComplete = function (DataFilter, idinput) {

        if ($scope.autoText[idinput] && $scope.autoText[idinput].length > 0) {
            $scope.filteredItems[idinput] = DataFilter.filter(function (item) {
                return item.name.toLowerCase().includes($scope.autoText[idinput].toLowerCase());
            });

            var dropdown = document.querySelector(`.autocomplete-dropdown-${idinput}`);
            if (dropdown) {
                dropdown.style.display = 'block';
            }
        } else {
            $scope.filteredItems[idinput] = DataFilter;
            var dropdown = document.querySelector(`.autocomplete-dropdown-${idinput}`);
        }
    };

    $scope.selectItem = function (item, idinput) {
        $scope.autoText[idinput] = item.name;
        $scope.filteredItems[idinput] = [];
        console.log($scope.autoText)

        var dropdown = document.querySelector(`.autocomplete-dropdown-${idinput}`);
        if (dropdown) {
            dropdown.style.display = 'none';
        }
    };
    $scope.confirmExport = function (seq, sub_software, data_type) {

        var user_name = $scope.user_name;
        sub_software = $scope.conditions[0].pha_sub_software.toLowerCase();


        $.ajax({
            url: url_ws + "Flow/export_" + sub_software + "_report",
            data: '{"sub_software":"' + sub_software + '","user_name":"' + user_name + '","seq":"' + seq + '","export_type":"' + data_type + '"}',
            type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
            beforeSend: function () {
                //$('#divLoading').show();

                $('#modalExportFile').modal('hide');
                $('#divLoading').show();
            },
            complete: function () {
                //$('#divLoading').hide();
                $('#divLoading').hide();
            },
            success: function (data) {
                var arr = data;

                if (arr.length > 0) {
                    if (arr[0].ATTACHED_FILE_NAME != '') {
                        var path = (url_ws).replace('/api/', '') + arr[0].ATTACHED_FILE_PATH;
                        var name = arr[0].ATTACHED_FILE_NAME;
                        $scope.exportfile[0].DownloadPath = path;
                        $scope.exportfile[0].Name = name;


                        $('#modalExportFile').modal('show');
                        //$('#divLoading').hide();
                        apply();
                    }
                } else {
                    set_alert('Error', arr[0].IMPORT_DATA_MSG);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    alert('Internal error: ' + jqXHR.responseText);
                } else {
                    alert('Unexpected ' + textStatus);
                }
            }

        });
    }

    $(document).ready(function () {
        page_load();
    });
});
