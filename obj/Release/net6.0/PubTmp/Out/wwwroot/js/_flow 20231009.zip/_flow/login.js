
angular.module('app', []).controller('ctrlApp', function ($scope, $filter) {
 
  $scope.check_authorization = function () {
  
  };


});