
AppMenuPage.filter('MemberteamMultiFieldFilter', function () {
    return function (items, searchText) {
        if (!searchText) {
            return items;
        }

        searchText = searchText.toLowerCase();

        return items.filter(function (item) {
            return (
                item.employee_id.toLowerCase().includes(searchText.toLowerCase()) ||
                item.employee_displayname.toLowerCase().includes(searchText.toLowerCase()) ||
                item.employee_email.toLowerCase().includes(searchText.toLowerCase())
            );
        });
    };
});
AppMenuPage.filter('ResponderMultiFieldFilter', function () {
    return function (items, searchResponderText) {
        if (!searchResponderText) {
            return items;
        }

        searchResponderText = searchResponderText.toLowerCase();

        return items.filter(function (item) {
            return (
                item.employee_id.toLowerCase().includes(searchResponderText.toLowerCase()) ||
                item.employee_displayname.toLowerCase().includes(searchResponderText.toLowerCase()) ||
                item.employee_email.toLowerCase().includes(searchResponderText.toLowerCase())
            );
        });
    };
});
AppMenuPage.filter('ApproverMultiFieldFilter', function () {
    return function (items, searchApproverText) {
        if (!searchApproverText) {
            return items;
        }

        searchApproverText = searchApproverText.toLowerCase();

        return items.filter(function (item) {
            return (
                item.employee_id.toLowerCase().includes(searchApproverText) ||
                item.employee_displayname.toLowerCase().includes(searchApproverText) ||
                item.employee_email.toLowerCase().includes(searchApproverText)
            );
        });
    };
});


AppMenuPage.controller("ctrlAppPage", function ($scope, $http, $filter, conFig) {
    //search list function
    $scope.autoComplete = function (DataFilter, idinput) {

        try {

            if ($scope.object_items_name != idinput) {
                var dropdown = document.querySelector(`.autocomplete-dropdown-${$scope.object_items_name}`);
                dropdown.style.display = 'block';
            }
            var dropdown = document.querySelector(`.autocomplete-dropdown-${idinput}`);
            $scope.object_items_name = idinput;

            if ($scope.autoText[idinput] && $scope.autoText[idinput].length > 0) {
                $scope.filteredItems[idinput] = DataFilter.filter(function (item) {
                    return item.name.toLowerCase().includes($scope.autoText[idinput].toLowerCase());
                });

                if (dropdown) {
                    dropdown.style.display = 'block';
                }
            } else {
                $scope.filteredItems[idinput] = DataFilter;
            }
        } catch (error) {

        }
    };

    $scope.selectItem = function (item, idinput) {
        $scope.autoText[idinput] = item.name;
        $scope.filteredItems[idinput] = [];
        //console.log($scope.autoText)
        try {
            var dropdown = document.querySelector(`.autocomplete-dropdown-${idinput}`);
            if (dropdown) {
                dropdown.style.display = 'none';
            }
        } catch (error) {

        }
    };

});
AppMenuPage.controller("ctrlAppPage", function ($scope, $http, $filter, conFig, $document) {
    //file:///D:/04KUL_PROJECT_2023/e-PHA/phoenix-v1.12.0/public/apps/email/compose.html

    $('#divLoading').hide();

    $document.on('keydown', function (event) {
        if (event.key == 'Escape') {
            // Perform your desired action here
            try {

                //var dropdown = document.querySelector(`.autocomplete-dropdown-${$scope.object_items_name}`);
                //dropdown.style.display = 'block'; 

                var _id = $scope.filteredArr[0].fieldID;
                const item_focus = document.getElementById(_id);
                // item_focus.focus();
                item_focus.blur();
                $scope.filteredArr[0].fieldID = null;

                // For example, you might want to close a modal or reset a form
                //$scope.$apply(); // If needed, trigger a digest cycle

            } catch (error) {

            }
        }
    });
    $scope.clearFileName = function (seq) {

        //var fileUpload = document.getElementById('attfile-' + inputId);
        //var fileNameDisplay = document.getElementById('filename' + inputId);
        //var del = document.getElementById('del-' + inputId);
        //fileUpload.value = ''; // ล้างค่าใน input file
        //fileNameDisplay.textContent = ''; // ล้างข้อความที่แสดงชื่อไฟล์
        //del.style.display = "none"; 
        var arr = $filter('filter')($scope.data_drawing,
            function (item) { return (item.seq == seq); }
        );
        if (arr.length > 0) {
            arr[0].document_file_name = null;
            arr[0].document_file_size = null;
            arr[0].document_file_path = null;
            arr[0].action_change = 1;
            apply();
        }

    };
    $scope.clearFileNameRAM = function (seq) {

        var arr = $filter('filter')($scope.master_ram, function (item) { return (item.seq == seq); });
        if (arr.length > 0) {
            arr[0].document_file_name = null;
            arr[0].document_file_size = null;
            arr[0].document_file_path = null;
            arr[0].action_change = 1;
            apply();
        }

    };

    $scope.changeTab = function (selectedTab, nameTab) {
        angular.forEach($scope.tabs, function (tab) {
            tab.isActive = false;
        });
        selectedTab.isActive = true;

        // Set focus to the clicked tab element
        try {
            // alert(event.target);
            //var ev = event.target;
            // if (ev == null || ev == undefined) {
            //     document.getElementById(selectedTab.name + "-tab").addEventListener("click", function (event) {
            //         ev = event.target
            //     });
            // } 
            document.getElementById(selectedTab.name + "-tab").addEventListener("click", function (event) {
                ev = event.target
            });

            var tabElement = angular.element(ev);
            tabElement[0].focus();
        } catch (error) { }

        check_tab(selectedTab.name);

        apply();
    };


    $scope.fileSelect = function (input) {


        const fileInput = input;
        const fileSeq = fileInput.id.split('-')[1];
        const fileInfoSpan = document.getElementById('filename' + fileSeq);

        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            const fileName = file.name;
            const fileSize = Math.round(file.size / 1024);
            fileInfoSpan.textContent = `${fileName} (${fileSize} KB)`;

            if (fileName.toLowerCase().indexOf('.pdf') == -1) {
                fileInfoSpan.textContent = "";
                set_alert('Warning', 'Please select a PDF file.');
                return;
            }

            var file_path = uploadFile(file, fileSeq, fileName, fileSize);

        } else {
            fileInfoSpan.textContent = "";
        }
    }
    $scope.fileSelectRAM = function (input) {


        const fileInput = input;
        const fileSeq = fileInput.id.split('-')[1];
        const fileInfoSpan = document.getElementById('filename_ram_' + fileSeq);

        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            const fileName = file.name;
            const fileSize = Math.round(file.size / 1024);
            fileInfoSpan.textContent = `${fileName} (${fileSize} KB)`;

            if (fileName.toLowerCase().indexOf('.pdf') == -1) {
                fileInfoSpan.textContent = "";
                set_alert('Warning', 'Please select a PDF file.');
                return;
            }

            var file_path = uploadFileRAM(file, fileSeq, fileName, fileSize);

        } else {
            fileInfoSpan.textContent = "";
        }
    }
    function uploadFileRAM(file_obj, seq, file_name, file_size) {

        var fd = new FormData();
        //Take the first selected file
        fd.append("file_obj", file_obj);
        fd.append("file_seq", seq);
        fd.append("file_name", file_name);

        try {
            const request = new XMLHttpRequest();
            request.open("POST", url_ws + 'Flow/uploadfile_data');
            request.send(fd);

            var arr = $filter('filter')($scope.master_ram, function (item) { return (item.seq == seq); });
            if (arr.length > 0) {
                arr[0].document_file_name = file_name;
                arr[0].document_file_size = file_size;
                arr[0].document_file_path = (url_ws.replace('/api/', '/')) + 'AttachedFileTemp/Whatif/' + file_name;
                arr[0].action_change = 1;
                apply();
            }
        } catch { }

        return "";
    }

    function uploadFile(file_obj, seq, file_name, file_size) {

        var fd = new FormData();
        //Take the first selected file
        fd.append("file_obj", file_obj);
        fd.append("file_seq", seq);
        fd.append("file_name", file_name);

        try {
            const request = new XMLHttpRequest();
            request.open("POST", url_ws + 'Flow/uploadfile_data');
            request.send(fd);

            var arr = $filter('filter')($scope.data_drawing, function (item) { return (item.seq == seq); });
            if (arr.length > 0) {
                arr[0].document_file_name = file_name;
                arr[0].document_file_size = file_size;
                arr[0].document_file_path = (url_ws.replace('/api/', '/')) + 'AttachedFileTemp/Whatif/' + file_name;
                arr[0].action_change = 1;
                apply();
            }
        } catch { }

        return "";
    }


    //  scroll  table header freezer 
    $scope.handleScroll = function () {
        const tableContainer = angular.element(document.querySelector('#table-container'));
        const thead = angular.element(document.querySelector('thead'));

        if (tableContainer && thead) {
            const containerRect = tableContainer[0].getBoundingClientRect();
            const containerTop = containerRect.top;
            const containerBottom = containerRect.bottom;

            const tableRect = thead[0].getBoundingClientRect();
            const tableTop = tableRect.top;
            const tableBottom = tableRect.bottom;

            if (containerTop > tableTop || containerBottom < tableBottom) {
                thead.addClass('sticky');
            } else {
                thead.removeClass('sticky');
            }
        }
    };

    $scope.showFileName = function (inputId) {
        var fileUpload = document.getElementById('file-upload-' + inputId);
        var fileNameDisplay = document.getElementById('fileNameDisplay-' + inputId);
        var del = document.getElementById('del' + inputId);

        if (fileUpload !== null) { // check ว่าตัวแปรเป็นค่าว่างไม 
            fileUpload.onchange = function () {
                const selectedFile = fileUpload.files[0].name; // get ชื่อไฟล์ 
                // console.log(selectedFile); // แสดงชื่อไฟล์ผ่าน console 
                fileNameDisplay.textContent = ' File is ' + selectedFile + '';
            };
            del.style.display = "block";
        } else {
            console.error("fileUpload null.");
        }
    };

    $scope.clearFileName_non_case = function (inputId) {
        var fileUpload = document.getElementById('file-upload-' + inputId);
        var fileNameDisplay = document.getElementById('fileNameDisplay-' + inputId);
        var del = document.getElementById('del' + inputId);
        fileUpload.value = ''; // ล้างค่าใน input file
        fileNameDisplay.textContent = ''; // ล้างข้อความที่แสดงชื่อไฟล์
        del.style.display = "none";
    };

    $scope.focusTask = function () {
        var tag_name = 'task';
        var arr_tab = $filter('filter')($scope.tabs, function (item) {
            return ((item.name == tag_name));
        });
        $scope.changeTab_Task(arr_tab, tag_name);
        document.getElementById("task_" + $scope.selectedItemTaskView).focus();
    }


    $scope.changeSearchApprover = function () {

    }

    $scope.showCauseText = function (responder_user_id, causes_no) {
        $scope.data_taskworksheet_show = [];
        var arr = $filter('filter')($scope.data_listworksheet, function (item) { return (item.responder_user_id == responder_user_id && item.list_system_no == list_system_no); });

        angular.copy(arr, $scope.data_taskworksheet_show);

        $('#modalCauseText').modal('show');
    };

    $scope.clickExportReport = function () {
        $('#modalExportImport').modal('show');
    }
    $scope.confirmExport = function (export_report_type, data_type) {

        var seq = $scope.data_header[0].seq;
        var user_name = $scope.user_name;

        var action_export_report_type = "whatif_report";

        if (export_report_type == "whatif_report") {
            action_export_report_type = "export_whatif_report";
        } else if (export_report_type == "whatif_worksheet") {
            action_export_report_type = "export_whatif_worksheet";
        } else if (export_report_type == "whatif_recommendation") {
            action_export_report_type = "export_whatif_recommendation";
        } else if (export_report_type == "whatif_ram") {
            action_export_report_type = "export_whatif_ram";
        } else {
            return;
        }

        $.ajax({
            url: url_ws + "Flow/" + action_export_report_type,
            data: '{"sub_software":"whatif","user_name":"' + user_name + '","seq":"' + seq + '","export_type":"' + data_type + '"}',
            type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
            beforeSend: function () {
                //$('#modalLoadding').modal('show');
                $('#divLoading').show();
            },
            complete: function () {
                //$('#modalLoadding').modal('hide');
                $('#divLoading').hide();
            },
            success: function (data) {
                var arr = data;

                if (arr.length > 0) {
                    if (arr[0].ATTACHED_FILE_NAME != '') {
                        var path = (url_ws).replace('/api/', '') + arr[0].ATTACHED_FILE_PATH;
                        var name = arr[0].ATTACHED_FILE_NAME;
                        $scope.exportfile[0].DownloadPath = path;
                        $scope.exportfile[0].Name = name;


                        $('#modalExportFile').modal('show');
                        //$('#modalLoadding').modal('hide');
                        apply();
                    }
                } else {
                    set_alert('Error', arr[0].IMPORT_DATA_MSG);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    alert('Internal error: ' + jqXHR.responseText);
                } else {
                    alert('Unexpected ' + textStatus);
                }
            }

        });

    }


    function replace_hashKey_arr(_arr) {
        var json = JSON.stringify(_arr, function (key, value) {
            if (key == "$$hashKey") {
                return undefined;
            }
            return value;
        });
        return json;
    }

    var url_ws = conFig.service_api_url();

    function arr_def() {
        $scope.object_items_name = null;

        $scope.selectViewTypeFollowup = true;

        $scope.action_part = 1;
        $scope.user_name = conFig.user_name();
        $scope.pha_seq = conFig.pha_seq();
        $scope.pha_type_doc = conFig.pha_type_doc();

        $scope.data_all = [];

        $scope.master_apu = [];
        $scope.master_bussiness_unit = [];
        $scope.master_unit_no = [];
        $scope.master_functional = [];
        $scope.master_ram = [];
        $scope.master_ram_level = [];
        $scope.master_security_level = [];
        $scope.master_likelihood_level = [];

        $scope.data_header = [];
        $scope.data_general = [];
        $scope.data_functional_audition = [];
        $scope.data_session = [];
        $scope.data_memberteam = [];
        $scope.data_drawing = [];
        $scope.data_task = [];
        $scope.data_taskdrawing = [];

        $scope.data_listworksheet = [];

        $scope.data_session_delete = [];
        $scope.data_memberteam_delete = [];
        $scope.data_drawing_delete = [];
        $scope.data_task_delete = [];
        $scope.data_taskdrawing_delete = [];

        $scope.data_listworksheet_delete = [];

        $scope.select_history_tracking_record = false;
        //$scope.functional_location_audition = ["TPX-76-LICSA-001-TX", "TPX-76-LICSA-002-TX", "TPX-76-LICSA-003-TX"];

        $scope.selectedItemTaskView = 0;
        $scope.selectedDataListworksheetRamType = null;

        $scope.select_rows_level = 4;
        $scope.select_columns_level = 4;
        $scope.selected_ram_img = (url_ws.replace('/api/', '/')) + 'AttachedFileTemp/rma-img-' + 4 + 'x' + 4 + '.png';

        $scope.data_taskworksheet_show = [];


        $scope.employeelist = [];

        // ล้างช่องข้อมูลหลังจากเพิ่มข้อความ
        $scope.employee_id = '';
        $scope.employee_name = '';
        $scope.employee_displayname = '';
        $scope.employee_email = '';
        $scope.employee_type = 'Contract';
        $scope.employee_img = 'assets/img/team/avatar.webp'

        $scope.searchdata = '';
        $scope.searchEmployee = '';

        $scope.sub_software = 'WHATIF';

        $scope.tabs = [
            { name: 'general', action_part: 1, title: 'General Information', isActive: true, isShow: false },
            { name: 'session', action_part: 2, title: $scope.sub_software + ' Session', isActive: false, isShow: false },
            { name: 'task', action_part: 3, title: 'Task', isActive: false, isShow: false },
            { name: 'ram', action_part: 4, title: 'RAM', isActive: false, isShow: false },
            { name: 'worksheet', action_part: 5, title: $scope.sub_software + ' Worksheet', isActive: false, isShow: false },
            { name: 'manage', action_part: 6, title: 'Manage Recommendations', isActive: false, isShow: false },
            { name: 'report', action_part: 7, title: 'Report', isActive: false, isShow: false }
        ];


        //file:///D:/04KUL_PROJECT_2023/e-PHA/phoenix-v1.12.0/public/apps/email/compose.html
        //console.log($scope.tabs);
    }

    function check_tab(val) {

        $scope.action_part = 1;
        var arr_tab = $filter('filter')($scope.tabs, function (item) { return (item.name == val); });
        if (arr_tab.length > 0) { $scope.action_part = Number(arr_tab[0].action_part); }
        if (val == 'worksheet') { $scope.viewDataTaskList($scope.selectedItemTaskView); }
    }

    function get_max_id() {
        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'session'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqDataSession = iMaxSeq;

        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'memberteam'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqDataMemberteam = iMaxSeq;

        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'drawing'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqDataDrawingDoc = iMaxSeq;

        //Task List
        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'task'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqDataTaskList = iMaxSeq;

        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'taskdrawing'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqDataTaskDrawing = iMaxSeq;

        //whorksheet
        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'listworksheet'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqdata_listworksheet = iMaxSeq;

        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'list'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqdata_listworksheetlist = iMaxSeq;

        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'listsub'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqdata_listworksheetlistsub = iMaxSeq;

        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'causes'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqdata_listworksheetcauses = iMaxSeq;

        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'consequences'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqdata_listworksheetconsequencese = iMaxSeq;

        var arr = $filter('filter')($scope.data_all.max, function (item) { return (item.name == 'category'); });
        var iMaxSeq = 1; if (arr.length > 0) { iMaxSeq = arr[0].values; }
        $scope.MaxSeqdata_listworksheetcategoryegory = iMaxSeq;



        $scope.selectdata_session = 1;
        $scope.selectdata_memberteam = 1;
        $scope.selectdata_drawing = 1;
        $scope.selectdata_task = 1;
        $scope.selectdata_listworksheet = 1;
        $scope.selectdata_listworksheetlist = 1;
        $scope.selectdata_listworksheetlistsub = 1;
        $scope.selectdata_listworksheetcauses = 1;
        $scope.selectdata_listworksheetconsequencese  = 1;
        $scope.selectdata_listworksheetcategoryegory = 1;

        $scope.exportfile = [{ DownloadPath: '', Name: '' }];
    }
    function apply() {
        try {
            if ($scope.$root.$$phase != '$apply' && $scope.$root.$$phase != '$digest') {
                $scope.$apply();
            }
        } catch { }
    }
    function replace_hashKey_arr(_arr) {
        var json = JSON.stringify(_arr, function (key, value) {
            if (key === "$$hashKey") {
                return undefined;
            }
            return value;
        });
        return json;
    }
    function page_load() {

        arr_def();

        if ($scope.user_name == null) {
            window.open('login/index', "_top");
            return;
        }

        get_data(true, false);
    }

    function save_data_create(action) {

        if ($scope.action_part != 4) { set_data_managerecom(); }

        check_data_general();
        check_data_functional_audition();

        var action_part = $scope.action_part;
        var user_name = $scope.user_name;
        var token_doc = $scope.token_doc + "";
        var pha_status = $scope.data_header[0].pha_status;
        var pha_version = $scope.data_header[0].pha_version;
        var pha_seq = $scope.data_header[0].seq;
        token_doc = pha_seq;

        var json_header = angular.toJson($scope.data_header);
        var json_general = angular.toJson($scope.data_general);
        var json_functional_audition = angular.toJson($scope.data_functional_audition);

        var json_session = check_data_session();
        var json_memberteam = check_data_memberteam();
        var json_drawing = check_data_drawing();

        var json_list = check_data_task();
        var json_listdrawing = check_data_taskdrawing();//angular.toJson($scope.data_taskdrawing);
        var json_listworksheet = check_data_listworksheet();


        //EPHA_M_RAM_LEVEL
        var json_ram_level = check_data_ram_level();
        var json_ram_master = check_master_ram();


        var flow_action = action;
        if (flow_action == 'yes') { flow_action = "submit"; }

        $.ajax({
            url: url_ws + "Flow/set_whatif",
            data: '{"user_name":"' + user_name + '","token_doc":"' + token_doc + '","pha_status":"' + pha_status + '","pha_version":"' + pha_version + '","action_part":"' + action_part + '"'
                + ',"json_header":' + JSON.stringify(json_header)
                + ',"json_general":' + JSON.stringify(json_general)
                + ',"json_functional_audition":' + JSON.stringify(json_functional_audition)
                + ',"json_session":' + JSON.stringify(json_session)
                + ',"json_memberteam":' + JSON.stringify(json_memberteam)
                + ',"json_drawing":' + JSON.stringify(json_drawing)
                + ',"json_list":' + JSON.stringify(json_list) //
                + ',"json_listdrawing":' + JSON.stringify(json_listdrawing) //
                + ',"json_listworksheet":' + JSON.stringify(json_listworksheet) //
                + ',"json_managerecom":' + JSON.stringify(json_managerecom)
                + ',"json_ram_level":' + JSON.stringify(json_ram_level)
                + ',"json_ram_master":' + JSON.stringify(json_ram_master)
                + ',"flow_action":' + JSON.stringify(flow_action)
                + '}',
            type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
            beforeSend: function () {
                //$('#modalLoadding').modal('show');
                //$('#modalMsg').modal('hide');
                $("#divLoading").show();

            },
            complete: function () {
                //$('#modalLoadding').modal('hide');
                $("#divLoading").hide();
            },
            success: function (data) {
                var arr = data;
                //console.log(arr);
                if (arr[0].status == 'true') {
                    $scope.pha_type_doc = 'update';
                    if (action == 'save') {

                        var controller_action_befor = conFig.controller_action_befor();
                        var pha_seq = conFig.pha_seq();
                        var pha_no = conFig.pha_no();
                        var pha_type_doc = "edit";

                        if (conFig.pha_seq() != null) {
                            pha_seq = arr[0].pha_seq;
                            pha_no = arr[0].pha_no;
                        }

                        var controller_text = "whatif";

                        $.ajax({
                            url: controller_text + "/set_session_doc",
                            data: '{"controller_action_befor":"' + controller_action_befor + '","pha_seq":"' + pha_seq + '"'
                                + ',"pha_no":"' + pha_no + '","pha_status":"' + pha_status + '","pha_type_doc":"' + pha_type_doc + '"}',
                            type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
                            beforeSend: function () {
                                $("#divLoading").show();
                            },
                            complete: function () {
                                $("#divLoading").hide();
                            },
                            success: function (data) {

                                set_alert('Success', 'Data has been successfully saved.');

                                if ($scope.pha_seq == null || $scope.pha_seq == '') {
                                    $scope.pha_seq = arr[0].seq_new;
                                    conFig.pha_seq[0] = arr[0].seq_new;
                                }

                                get_data_after_save(false, (flow_action == 'submit' ? true : false), $scope.pha_seq);
                            },
                            error: function (jqXHR, textStatus, errorThrown) {
                                if (jqXHR.status == 500) {
                                    alert('Internal error: ' + jqXHR.responseText);
                                } else {
                                    alert('Unexpected ' + textStatus);
                                }
                            }

                        });


                    } else {
                        set_alert('Success', 'Data has been successfully submitted.');
                        window.open('whatif/search', "_top");
                        return;
                    }
                } else {
                    apply();
                    set_alert('Error', arr[0].status);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    alert('Internal error: ' + jqXHR.responseText);
                } else {
                    alert('Unexpected ' + textStatus);
                }
            }

        });

    }

    function get_data(page_load, action_submit) {
    
        var user_name = conFig.user_name();
        var pha_seq = conFig.pha_seq();
        if (page_load == true) {
            $scope.pha_seq = pha_seq;
            $scope.user_name = user_name;
        } else { pha_seq = $scope.pha_seq; }

        call_api_load(page_load, action_submit, user_name, pha_seq);
    }
    function get_data_after_save(page_load, action_submit, pha_seq) {
        var user_name = conFig.user_name();
        call_api_load(false, action_submit, user_name, pha_seq);
    }
    function call_api_load(page_load, action_submit, user_name, pha_seq) {


        var type_doc = $scope.pha_type_doc;//review_document

        $.ajax({
            url: url_ws + "Flow/get_whatif_details",
            data: '{"sub_software":"whatif","user_name":"' + user_name + '","token_doc":"' + pha_seq + '","type_doc":"' + type_doc + '"}',
            type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
            beforeSend: function () {
                $('#divLoading').show();
            },
            complete: function () {
                $('#divLoading').hide();
            },
            success: function (data) {
                var action_part_befor = $scope.action_part;//(page_load == false ? $scope.action_part : 0);
                var tabs_befor = (page_load == false ? $scope.tabs : null);

                var arr = data;
                if (true) {
                    $scope.data_all = arr;
                    $scope.master_apu = arr.apu;
                    $scope.master_business_unit = arr.business_unit;
                    $scope.master_unit_no = arr.unit_no;
                    $scope.master_functional = arr.functional;
                    $scope.master_functional_audition = arr.functional;//ใช้ใน functional audition

                    //แก้ไขเบื้องต้น เนื่องจาก path file ผิดต้องเป็น folder whatif
                    for (let i = 0; i < arr.ram.length; i++) {
                        arr.ram[i].document_file_path = (url_ws.replace('/api/', '/')) + arr.ram[i].document_file_path;
                    }
                    $scope.master_ram = arr.ram;
                    $scope.master_ram_level = arr.ram_level;
                    $scope.master_ram_color = arr.ram_color;
                    $scope.master_ram_priority = [{ id: 1, name: 'H' }, { id: 2, name: 'M' }, { id: 3, name: 'L' }, { id: 4, name: 'N' }, { id: 5, name: 'N/A' }];
                    $scope.master_ram_criterion = [{ id: 'N', name: 'N' }, { id: 'Y', name: 'Y' }];
                    $scope.master_security_level = arr.security_level;
                    $scope.master_likelihood_level = arr.likelihood_level;
                    $scope.master_no = [{ id: 4, name: 4 }, { id: 5, name: 5 }, { id: 6, name: 6 }, { id: 7, name: 7 }, { id: 8, name: 8 }, { id: 9, name: 9 }, { id: 10, name: 10 }];
                    $scope.ram_rows_level = 4;
                    $scope.ram_columns_level = 4;

                    $scope.employeelist = arr.employee;

                    arr.header[0].safety_critical_equipment_show = (arr.header[0].safety_critical_equipment_show == null ? 0 : arr.header[0].safety_critical_equipment_show);
                    $scope.data_header = arr.header;
                    var inputs = document.getElementsByTagName('sceSwitchCheckChecked');
                    for (var i = 0; i < inputs.length; i++) {
                        if (inputs[i].type == 'checkbox') {
                            if ($scope.data_header[0].safety_critical_equipment_show == 1) {
                                inputs[i].checked = true;
                            } else { inputs[i].checked = false; }
                        }
                    }


                    $scope.data_general = arr.general;

                    $scope.data_functional_audition = arr.functional_audition;

                    $scope.data_session = arr.session;
                    $scope.data_session_def = clone_arr_newrow(arr.session);

                    $scope.data_memberteam = arr.memberteam;
                    $scope.data_memberteam_def = clone_arr_newrow(arr.memberteam);
                    $scope.data_memberteam_old = (arr.memberteam);

                    $scope.data_drawing = arr.drawing;
                    $scope.data_drawing_def = clone_arr_newrow(arr.drawing);

                    $scope.data_task = arr.list;
                    $scope.data_task_def = clone_arr_newrow(arr.list);


                    for (let i = 0; i < arr.listdrawing; i++) {

                        if (arr.listdrawing[i].document_file_path.indexOf('/FollowUp/') > -1) {
                            arr.listtaskdrawing[i].document_file_path = arr.listdrawing[i].document_file_path.replace('/FollowUp/', '/whatif/');
                        }
                    }
                    $scope.data_taskdrawing = arr.listdrawing;
                    $scope.data_taskdrawing_def = clone_arr_newrow(arr.listdrawing);

                    // set initial NO
                    let systemNo = ['list_system_no', 'list_sub_system_no', 'causes_no', 'consequences_no'];

                    arr.listworksheet.forEach(obj => {
                      systemNo.forEach(key => {
                        if (obj[key] === null) {
                          obj[key] = 1;
                        }
                      });
                    });                   

                    $scope.data_listworksheet = arr.listworksheet;
                    console.log($scope.data_listworksheet)
                    $scope.data_listworksheet_def = clone_arr_newrow(arr.listworksheet);

                

                    $scope.master_apu = JSON.parse(replace_hashKey_arr(arr.apu));


                    $scope.data_attendees = arr.attendees;
                    $scope.data_attendees_def = clone_arr_newrow(arr.attendees);
                    $scope.data_attendees_old = arr.attendees;

                    $scope.data_specialist = arr.specialist;
                    $scope.data_specialist_def = clone_arr_newrow(arr.specialist);
                    $scope.data_specialist_old = arr.specialist;

                    //$scope.data_reviewer = arr.reviewer;
                    //$scope.data_approver = arr.approver;                    

                    get_max_id();
                    set_data_general();
                    set_data_listworksheet();
                    set_master_ram_likelihood('');

                    //get recommendations_no in task worksheet
                    if ($scope.data_listworksheet.length > 0) {
                        var arr_copy_def = angular.copy($scope.data_listworksheet, arr_copy_def);
                        arr_copy_def.sort((a, b) => Number(b.recommendations_no) - Number(a.recommendations_no));
                        var recommendations_no = Number(Number(arr_copy_def[0].recommendations_no) + 1);
                        for (let i = 0; i < $scope.data_listworksheet; i++) {
                            if ($scope.data_listworksheet[i].recommendations == null || $scope.data_listworksheet[i].recommendations == '') {
                                if ($scope.data_listworksheet[i].recommendations_no == null || $scope.data_listworksheet[i].recommendations_no == '') {
                                    $scope.data_listworksheet[i].recommendations_no = recommendations_no;
                                    recommendations_no += 1;
                                }
                            }
                        }
                    }

                }

                $scope.data_session_delete = [];
                $scope.data_memberteam_delete = [];
                $scope.data_drawing_delete = [];
                $scope.data_listworksheet_delete = [];
                $scope.data_task_delete = [];
                $scope.data_taskdrawing_delete = [];
                $scope.flow_role_type = conFig.role_type();// "admin";//admin,request,responder,approver
                $scope.flow_status = 0;

                //แสดงปุ่ม
                $scope.flexSwitchCheckChecked = false;
                $scope.back_type = true;
                $scope.cancle_type = false;
                $scope.export_type = false;
                $scope.save_type = true;
                $scope.submit_review = true;
                $scope.submit_type = true;

                $scope.selectActiveNotification = ($scope.data_header[0].active_notification == 1 ? true : false);

                set_form_action(action_part_befor, !action_submit, page_load);

                if (true) {

                    if (!page_load) {
                        if (!action_submit) {
                            $scope.action_part = action_part_befor;
                            $scope.tabs = tabs_befor;
                        }
                    }

                    var i = 0;
                    var id_ram = $scope.data_general[0].id_ram;
                    var arr_items = $filter('filter')($scope.master_ram_level, function (item) { return (item.id_ram == id_ram); });
                    if (arr_items.length > 0) {

                        $scope.select_rows_level = arr_items[0].rows_level;
                        $scope.select_columns_level = arr_items[0].columns_level;
                        $scope.selected_ram_img = (url_ws.replace('/api/', '/')) + arr_items[0].document_file_path;
                    }

                    try {
                        $scope.master_apu = JSON.parse(replace_hashKey_arr(arr.apu));
                        $scope.master_functional = JSON.parse(replace_hashKey_arr(arr.functional));
                        $scope.master_business_unit = JSON.parse(replace_hashKey_arr(arr.business_unit));
                        $scope.master_unit_no = JSON.parse(replace_hashKey_arr(arr.unit_no));

                        //$scope.master_business_unit_show = $filter('filter')($scope.master_business_unit, function (item) {
                        //    return (item.id_apu == $scope.data_general[0].id_apu);
                        //});

                        if ($scope.data_general[0].master_apu == null || $scope.data_general[0].master_apu == '') {
                            $scope.data_general[0].master_apu = null;
                            //var arr_clone_def = { id: $scope.data_general[0].master_apu, name: 'Please select' };
                            var arr_clone_def = { id: null, name: 'Please select' };
                            $scope.master_apu.splice(0, 0, arr_clone_def);
                        }
                        if ($scope.data_general[0].master_functional == null || $scope.data_general[0].master_functional == '') {
                            $scope.data_general[0].master_functional = null;
                            //var arr_clone_def = { id: $scope.data_general[0].master_functional, name: 'Please select' };
                            var arr_clone_def = { id: null, name: 'Please select' };
                            $scope.master_functional.splice(0, 0, arr_clone_def);
                        }
                        if ($scope.data_general[0].id_business_unit == null) {
                            $scope.data_general[0].id_business_unit = null;
                            //var arr_clone_def = { id: $scope.data_general[0].id_business_unit, name: 'Please select' };
                            var arr_clone_def = { id: null, name: 'Please select' };
                            $scope.master_business_unit.splice(0, 0, arr_clone_def);
                        }
                        if ($scope.data_general[0].master_unit_no == null || $scope.data_general[0].master_unit_no == '') {
                            $scope.data_general[0].master_unit_no = null;
                            //var arr_clone_def = { id: $scope.data_general[0].master_unit_no, name: 'Please select' };
                            var arr_clone_def = { id: null, name: 'Please select' };
                            $scope.master_unit_no.splice(0, 0, arr_clone_def);
                        }
                    } catch (ex) { alert(ex); console.clear(); }


                    $scope.$apply();
                    try {
                        if (page_load == true || true) {
                            const choices1 = new Choices('.js-choice-apu');
                            const choices2 = new Choices('.js-choice-functional');
                            const choices3 = new Choices('.js-choice-business_unit');
                            const choices4 = new Choices('.js-choice-unit_no');

                            const choices5 = new Choices('.js-choice-functional_audition');
                        }
                    } catch { }



                    //console.log($scope);
                }

            },
            error: function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    alert('Internal error: ' + jqXHR.responseText);
                } else {
                    alert('Unexpected ' + textStatus);
                }
            }

        });

    }

    function set_form_action(action_part_befor, action_save, page_load) {

        //แสดง tab ตาม flow
        $scope.tab_general_show = true;
        $scope.tab_worksheet_show = false;
        $scope.tab_managerecom_show = false;

        //เปิดให้แก้ไขข้อมูลในแต่ละ tab ตาม flow
        $scope.tab_general_active = true;
        $scope.tab_worksheet_active = true;
        $scope.tab_managerecom_active = true;

        for (let _item of $scope.tabs) {
            _item.isShow = true;
            _item.isActive = false;
        }

        $scope.action_part = action_part_befor;

            $scope.submit_review = false;
        if (Number($scope.data_header[0].pha_status) == 81) {
            $scope.back_type = true;
            $scope.cancle_type = false;
            $scope.export_type = false;
            $scope.save_type = false;
            $scope.submit_type = false;
            $scope.submit_review = false;
            return;
        } else {
            $scope.export_type = true;
        }

        if ($scope.data_header[0].pha_status == 11) {

            if (page_load) {

                var tag_name = 'general';
                var arr_tab = $filter('filter')($scope.tabs, function (item) {
                    return ((item.action_part == $scope.action_part));
                });
                if (arr_tab.length > 0) {
                    $scope.changeTab(arr_tab[0], tag_name);
                    if (action_save == true) { $scope.action_part = arr_tab[0].action_part; }
                }

                $scope.cancle_type = true;
            }

            if ($scope.data_general[0].sub_expense_type == 'Study') {
                check_case_sub_expense_type();
            }

        }
        else if ($scope.data_header[0].pha_status == 12) {
            var tag_name = 'worksheet';
            var arr_tab = $filter('filter')($scope.tabs, function (item) {
                return ((item.name == tag_name));
            });
            if (arr_tab.length > 0) {
                $scope.changeTab(arr_tab[0], tag_name);
                if (action_save == true) { $scope.action_part = arr_tab[0].action_part; }
            }

            check_case_member_review();

            $scope.tab_worksheet_show = true;
            $scope.tab_managerecom_show = true;
            if ($scope.data_listworksheet.length == 0) { $scope.tab_managerecom_show = false; }

            $scope.tab_worksheet_show = true;

            $scope.selectedItemTaskView = $scope.data_task[0].seq;

            $scope.submit_type = true;

            $scope.tab_general_active = true;
            $scope.tab_task_active = true;            
            $scope.tab_worksheet_active = true;
            $scope.tab_managerecom_active = true;
            //$scope.tab_managerecom_active = $scope.tab_managerecom_show;
        }
        else if ($scope.data_header[0].pha_status == 13) {
            $scope.tab_worksheet_show = true;
            $scope.tab_managerecom_show = true;
            if ($scope.data_listworksheet.length == 0) { $scope.tab_managerecom_show = false; }

            $scope.tab_worksheet_active = true;
            $scope.selectedItemTaskView = $scope.data_task[0].seq;            

            var tag_name = 'manage';
            var arr_tab = $filter('filter')($scope.tabs, function (item) {
                return ((item.name == tag_name));
            });
            if (arr_tab.length > 0) {
                $scope.changeTab(arr_tab[0], tag_name);
                if (action_save == true) { $scope.action_part = arr_tab[0].action_part; }
            }

            $scope.tab_general_active = false;
            $scope.tab_task_active = false;
            $scope.tab_worksheet_active = false;
            $scope.tab_managerecom_active = false;

            $scope.save_type = false;
            $scope.submit_type = false;
        }
        else if (Number($scope.data_header[0].pha_status) == 21) {

            $scope.tab_general_show = true;
            $scope.tab_task_show = true;
            $scope.tab_worksheet_show = true;
            $scope.tab_managerecom_show = true;
            $scope.tab_worksheet_active = true;

            $scope.selectedItemTaskView = $scope.data_task[0].seq;

            $scope.save_type = true;
            $scope.submit_type = true;

            var tag_name = 'manage';
            var arr_tab = $filter('filter')($scope.tabs, function (item) {
                return ((item.name == tag_name));
            });
            if (arr_tab.length > 0) {
                $scope.changeTab(arr_tab[0], tag_name);
                if (action_save == true) { $scope.action_part = arr_tab[0].action_part; }
            }

            $scope.selectSendBack = ($scope.data_header[0].approve_status == 'approve' ? 'option1' : 'option2');


            $scope.tab_general_active = false;
            $scope.tab_worksheet_active = false;
            $scope.tab_managerecom_active = $scope.tab_managerecom_show;

        }
        else if ($scope.data_header[0].pha_status == 14) {
            $scope.tab_general_show = true;
            $scope.tab_task_show = true;
            $scope.tab_worksheet_show = true;
            $scope.tab_managerecom_show = true;

            $scope.tab_worksheet_active = true;

            $scope.selectedItemTaskView = $scope.data_task[0].seq;

            if ($scope.flow_role_type == "admin") {
                $scope.save_type = true;
                $scope.submit_type = true;
            }
            var tag_name = 'manage';
            var arr_tab = $filter('filter')($scope.tabs, function (item) {
                return ((item.name == tag_name));
            });
            if (arr_tab.length > 0) {
                $scope.changeTab(arr_tab[0], tag_name);
                if (action_save == true) { $scope.action_part = arr_tab[0].action_part; }
            }

            $scope.tab_general_active = false;
            $scope.tab_worksheet_active = false;
            $scope.tab_managerecom_active = $scope.tab_managerecom_show;
        }
        else if ($scope.data_header[0].pha_status == 91) {
            $scope.tab_general_show = true;
            $scope.tab_task_show = true;
            $scope.tab_worksheet_show = true;
            $scope.tab_managerecom_show = true;

            $scope.tab_general_active = false;

            $scope.tab_worksheet_active = false;
            $scope.tab_managerecom_active = false;
            $scope.tab_task_active = false;
            $scope.save_type = false;
            $scope.submit_type = false;
            $scope.export_type = true;

            $scope.selectedItemTaskView = $scope.data_task[0].seq;

            var tag_name = 'manage';
            var arr_tab = $filter('filter')($scope.tabs, function (item) {
                return ((item.name == tag_name));
            });
            if (arr_tab.length > 0) {
                $scope.changeTab(arr_tab[0], tag_name);
                if (action_save == true) { $scope.action_part = arr_tab[0].action_part; }
            }

        }

        if ($scope.data_header[0].pha_status == 91 || $scope.data_header[0].pha_status == 81) {

        } else {

            $scope.tab_general_active = true;
            $scope.tab_worksheet_active = true;
            $scope.tab_managerecom_active = true;

        }

        if ($scope.pha_type_doc == 'review_document') {
            $scope.tab_general_active = false;
            $scope.tab_worksheet_active = false;
            $scope.tab_managerecom_active = false;

            $scope.back_type = true;
            $scope.cancle_type = false;
            $scope.export_type = true;
            $scope.save_type = false;
            $scope.submit_type = false;
            $scope.submit_review = false;
        }
    }
    function check_case_member_review(){
        
        if ($scope.data_session.length > 0) {
            var icount = $scope.data_session.length - 1;
            var id_session = $scope.data_session[icount].seq;
            var arr_team = $filter('filter')($scope.data_memberteam, function (item) {
                return ((item.id_session == id_session));
            });
            if (arr_team.length > 0) { $scope.submit_review = true; }
        }
    }
    function check_case_sub_expense_type() {

        if ($scope.data_general[0].sub_expense_type == 'Study') {
            //แสดง tab ตาม flow กรณีที่เป้น study ให้แสดงทุกรายการ
            $scope.tab_general_show = true;
            $scope.tab_task_show = true;            
            $scope.tab_worksheet_show = true;
            $scope.tab_managerecom_show = true;


            $scope.tab_general_active = true;
            $scope.tab_task_active = true;
            $scope.tab_worksheet_active = true;
            $scope.tab_managerecom_active = true;

            if ($scope.selectedItemTaskView == 0) {
                if ($scope.data_task.length > 0) {
                    $scope.selectedItemTaskView = $scope.data_task[0].seq;
                }
            }

        }

    }
    function set_data_general() {

        if (($scope.data_general[0].id_ram + '') == '') {
            $scope.data_general[0].id_ram = 1;
        }

        if ($scope.data_general[0].target_start_date !== null) {
            const x = ($scope.data_general[0].target_start_date.split('T')[0]).split("-");
            $scope.data_general[0].target_start_date = new Date(x[0], x[1], x[2]);
        }
        if ($scope.data_general[0].target_end_date !== null) {
            const x = ($scope.data_general[0].target_end_date.split('T')[0]).split("-");
            $scope.data_general[0].target_end_date = new Date(x[0], x[1], x[2]);
        }
        if ($scope.data_general[0].actual_start_date !== null) {
            const x = ($scope.data_general[0].actual_start_date.split('T')[0]).split("-");
            $scope.data_general[0].actual_start_date = new Date(x[0], x[1], x[2]);
        }
        if ($scope.data_general[0].actual_end_date !== null) {
            const x = ($scope.data_general[0].actual_end_date.split('T')[0]).split("-");
            $scope.data_general[0].actual_end_date = new Date(x[0], x[1], x[2]);
        }

        for (let i = 0; i < $scope.data_session.length; i++) {
            $scope.data_session[i].no = (i + 1);

            if ($scope.data_session[i].meeting_date !== null) {
                const x = ($scope.data_session[i].meeting_date.split('T')[0]).split("-");
                $scope.data_session[i].meeting_date = new Date(x[0], x[1], x[2]);
            }
            if ($scope.data_session[i].meeting_start_time !== null) {
                //12/31/1969 7:55:00 PM
                const x = ($scope.data_session[i].meeting_start_time.split(' ')[1]).split(":");
                const x2 = $scope.data_session[i].meeting_start_time.split(' ')[2];
                var hh = ('00' + (x2 == "PM" ? x[0] + 12 : x[0])); var mm = ('00' + x[1]);
                var valtime = "1970-01-01T" + (hh).substring(hh.length - 2) + ":" + (mm).substring(mm.length - 2) + ":00.000Z";
                $scope.data_session[i].meeting_start_time = new Date(valtime);
            }
            if ($scope.data_session[i].meeting_end_time !== null) {
                //12/31/1969 7:55:00 PM
                const x = ($scope.data_session[i].meeting_end_time.split(' ')[1]).split(":");
                const x2 = $scope.data_session[i].meeting_end_time.split(' ')[2];
                var hh = ('00' + (x2 == "PM" ? x[0] + 12 : x[0])); var mm = ('00' + x[1]);
                var valtime = "1970-01-01T" + (hh).substring(hh.length - 2) + ":" + (mm).substring(mm.length - 2) + ":00.000Z";
                $scope.data_session[i].meeting_end_time = new Date(valtime);
            }
        }

        var functional_location_audition = $scope.data_general[0].functional_location_audition;
        //var xSplitFunc = (functional_audition).replaceAll('"','').replace('[','').replace(']','').split(",");
        var xSplitFunc = (functional_location_audition).replaceAll('"', '').replace('[', '').replace(']', '').split(",");
        var _functoArr = [];
        for (var i = 0; i < xSplitFunc.length; i++) {
            _functoArr.push(xSplitFunc[i]);
        }
        //console.log('_functoArr');
        $scope.data_general[0].functional_location_audition = _functoArr;
        //console.log($scope.data_general[0].functional_location_audition);
        return;
    }

    function set_data_listworksheet() {

        var bCheckNewRows = false;
        if ($scope.data_listworksheet) {
            var arr = $filter('filter')($scope.data_listworksheet, function (item) { return (item.action_type == 'new'); });
            if (arr.length > 0) {
                var newInput = clone_arr_newrow($scope.data_listworksheet_def)[0];
                $scope.data_listworksheet = [];
                $scope.data_listworksheet.push(newInput);
                bCheckNewRows = true;
            }
        }
    }

    function set_master_ram_likelihood(ram_select) {


        $scope.master_ram_likelihood = [];
        var id_ram = $scope.data_general[0].id_ram;
        if (ram_select != '') { id_ram = ram_select; }

        var arr_items = $filter('filter')($scope.master_ram_level, function (item) { return (item.id_ram == id_ram); });

        var i = 0; var columns_level = 0;
        if (arr_items.length > 0) {
            columns_level = Number(arr_items[0].columns_level);
            $scope.select_rows_level = arr_items[0].rows_level;
            $scope.select_columns_level = arr_items[0].columns_level;
        }
        if (columns_level !== 5 || true) {
            var arr = [
                { columns_level: columns_level, seq: 1, level: arr_items[i].likelihood1_level, text: '', desc: '', criterion: '' }
                , { columns_level: columns_level, seq: 2, level: arr_items[i].likelihood2_level, text: '', desc: '', criterion: '' }
                , { columns_level: columns_level, seq: 3, level: arr_items[i].likelihood3_level, text: '', desc: '', criterion: '' }
                , { columns_level: columns_level, seq: 4, level: arr_items[i].likelihood4_level, text: '', desc: '', criterion: '' }
                , { columns_level: columns_level, seq: 5, level: arr_items[i].likelihood5_level, text: '', desc: '', criterion: '' }
                , { columns_level: columns_level, seq: 6, level: arr_items[i].likelihood6_level, text: '', desc: '', criterion: '' }
                , { columns_level: columns_level, seq: 7, level: arr_items[i].likelihood7_level, text: '', desc: '', criterion: '' }
                , { columns_level: columns_level, seq: 8, level: arr_items[i].likelihood8_level, text: '', desc: '', criterion: '' }
                , { columns_level: columns_level, seq: 9, level: arr_items[i].likelihood9_level, text: '', desc: '', criterion: '' }
                , { columns_level: columns_level, seq: 10, level: arr_items[i].likelihood10_level, text: '', desc: '', criterion: '' }
            ]
        } else {
            var arr = [
                { columns_level: columns_level, seq: 1, level: arr_items[i].likelihood1_level, text: arr_items[i].likelihood1_text, desc: arr_items[i].likelihood1_desc, criterion: arr_items[i].likelihood1_criterion }
                , { columns_level: columns_level, seq: 2, level: arr_items[i].likelihood2_level, text: arr_items[i].likelihood2_text, desc: arr_items[i].likelihood2_desc, criterion: arr_items[i].likelihood2_criterion }
                , { columns_level: columns_level, seq: 3, level: arr_items[i].likelihood3_level, text: arr_items[i].likelihood3_text, desc: arr_items[i].likelihood3_desc, criterion: arr_items[i].likelihood3_criterion }
                , { columns_level: columns_level, seq: 4, level: arr_items[i].likelihood4_level, text: arr_items[i].likelihood4_text, desc: arr_items[i].likelihood4_desc, criterion: arr_items[i].likelihood4_criterion }
                , { columns_level: columns_level, seq: 5, level: arr_items[i].likelihood5_level, text: arr_items[i].likelihood5_text, desc: arr_items[i].likelihood5_desc, criterion: arr_items[i].likelihood5_criterion }
            ]
        }
        $scope.master_ram_likelihood = arr;

    }
    function set_data_managerecom() {

        if (true) {
            var arr_worksheet = $scope.data_listworksheet;
            for (var w = 0; w < arr_worksheet.length; w++) {

                //recommendations_no
                arr_worksheet[w].recommendations_no = (arr_worksheet[w].recommendations_no == null ? arr_worksheet[w].list_sub_system_no : null);

                //Estimated Date  
                try {
                    if (arr_worksheet[w].estimated_start_date !== null) {
                        const x = (arr_worksheet[w].estimated_start_date.split('T')[0]).split("-");
                        if (x[0] > 2000) {
                            arr_worksheet[w].estimated_start_date = new Date(x[0], x[1], x[2]);
                        }
                    }
                } catch { }
                try {
                    if (arr_worksheet[w].estimated_end_date !== null) {
                        const x = (arr_worksheet[w].estimated_end_date.split('T')[0]).split("-");
                        if (x[0] > 2000) {
                            arr_worksheet[w].estimated_end_date = new Date(x[0], x[1], x[2]);
                        }
                    }
                } catch { }

            }
        }

    }

    // <==== (Kul)Session zone function  ====>    
    function clone_arr_newrow(arr_items) {
        var arr_clone = []; var arr_clone_def = [];
        try {
            angular.copy(arr_items, arr_clone_def);

            if (arr_clone_def.length > 0) {
                arr_clone_def = arr_clone_def.map(function (item) {
                    var newObj = {};
                    for (var key in item) {
                        newObj[key] = null;
                    }
                    return newObj;

                });
                arr_clone.push(arr_clone_def[0]);
            } else { arr_clone = arr_clone_def; }

        } catch { }
        return arr_clone;
    }
    function running_no_level1_lv1(arr_items, iNo, iRow, newInput) {

        arr_items.sort((a, b) => a.no - b.no);
        var first_row = true;
        var iNoNew = iNo;
        if (newInput == null) {
            iNo = (iNo == null ? 1 : iNo) + 0;
            iNoNew = iNo;
        }

        for (let i = (iRow); i < arr_items.length; i++) {

            if (first_row == true && newInput !== null) {
                iNoNew++;
                newInput.no = (iNoNew);
                first_row = false;
            } else {
                arr_items[i].no = iNoNew;
            }
            iNoNew++;
        };
        if (newInput !== null) {
            //if (iRow > 0) { newInput.no = Number(newInput.no) + 0.1; } 
            arr_items.push(newInput);
        }
        arr_items.sort((a, b) => a.no - b.no);

    }
    function running_no_level1(arr_items, iNo, newInput) {

        arr_items.sort((a, b) => a.no - b.no);
        var first_row = true;
        var iNoNew = iNo;
        if (newInput == null) {
            iNo = (iNo == null ? 1 : iNo) + 0;
            iNoNew = iNo;
        }

        for (let i = (iNo); i < arr_items.length; i++) {

            if (first_row == true && newInput !== null) {
                iNoNew++;
                newInput.no = (iNoNew);
                first_row = false;
            } else {
                arr_items[i].no = iNoNew;
            }
            iNoNew++;
        };
        if (newInput !== null) { arr_items.push(newInput); }
        arr_items.sort((a, b) => a.no - b.no);

    }
    $scope.addDataSession = function (seq) {

        $scope.MaxSeqDataSession = ($scope.MaxSeqDataSession) + 1;
        var xValues = $scope.MaxSeqDataSession;

        var arr = $filter('filter')($scope.data_session, function (item) { return (item.seq == seq); });
        var iNo = 1; if (arr.length > 0) { iNo = arr[0].no; }

        var newInput = clone_arr_newrow($scope.data_session_def)[0];
        newInput.seq = xValues;
        newInput.id = xValues;
        newInput.no = (iNo + 1);
        newInput.action_type = 'insert';
        newInput.action_change = 1;
        console.clear();
        //console.log(newInput);

        running_no_level1($scope.data_session, iNo, newInput);

        $scope.selectdata_session = xValues;
    }
    $scope.copyDataSession = function (seq) {

        $scope.MaxSeqDataSession = Number($scope.MaxSeqDataSession) + 1;
        var xValues = $scope.MaxSeqDataSession;

        var id_session = xValues;
        var arr = $filter('filter')($scope.data_session, function (item) { return (item.seq == seq); });
        var iNo = 1; if (arr.length > 0) { iNo = arr[0].no; }
        for (let i = 0; i < arr.length; i++) {

            var newInput = clone_arr_newrow($scope.data_session_def)[0];
            newInput.seq = Number(xValues);
            newInput.id = Number(xValues);
            newInput.no = (iNo + 1);
            newInput.action_type = 'insert';
            newInput.action_change = 1;
            newInput.meeting_date = arr[i].meeting_date;
            newInput.meeting_start_time = arr[i].meeting_start_time;
            newInput.meeting_end_time = arr[i].meeting_end_time;

        };

        running_no_level1($scope.data_session, iNo, newInput);

        $scope.selectdata_session = xValues;

        var arr_copy = [];
        angular.copy($scope.data_memberteam, arr_copy);
        var arrmember = $filter('filter')(arr_copy, function (item) { return (item.id_session == seq); });
        for (let i = 0; i < arrmember.length; i++) {
            arrmember[i].id_session = Number(id_session);
            arrmember[i].action_type = 'insert';
            arrmember[i].action_change = 1;

            arrmember[i].seq = $scope.selectdata_memberteam;
            arrmember[i].id = $scope.selectdata_memberteam;

            $scope.data_memberteam.push(arrmember[i]);
            $scope.selectdata_memberteam += 1;
        }
    }
    $scope.removeDataSession = function (seq) {
        var arrdelete = $filter('filter')($scope.data_session, function (item) {
            return (item.seq == seq && item.action_type == 'update');
        });
        if (arrdelete.length > 0) { $scope.data_session_delete.push(arrdelete[0]); }

        $scope.data_session = $filter('filter')($scope.data_session, function (item) {
            return !(item.seq == seq);
        });
        if ($scope.data_session.length == 0) {
            $scope.addDataSession();
        }
        running_no_level1($scope.data_session, null, null);
    };
    $scope.openModalEmployeeCheck = function (seq) {
        $scope.selectdata_session = seq;

        var arr = $scope.employeelist;
        for (let i = 0; i < arr.length; i++) {

            var ar_check = $filter('filter')($scope.data_memberteam
                , { id_session: seq, user_name: arr[i].employee_name });
            if (ar_check.length > 0) {
                $scope.employeelist[i].selected = true;
            } else {
                $scope.employeelist[i].selected = false;
            }
        };
        apply();

        $('#modalEmployeeCheck').modal('show');
    };
    $scope.AddDataEmpSession = function () {

        var seq_session = $scope.selectdata_session;
        var arr = $filter('filter')($scope.employeelist, { selected: true });

        var arr_def = [];
        for (let i = 0; i < arr.length; i++) {

            var ar_check = $filter('filter')($scope.data_memberteam
                , { id_session: seq_session, user_name: arr[i].employee_name });

            if (ar_check.length > 0) {

                if (ar_check[0].user_displayname !== arr[i].employee_displayname) {
                    ar_check[0].user_displayname = arr[i].employee_displayname;
                    ar_check[0].action_change = 1;
                }
                arr_def.push(ar_check[0]);
                continue;
            }

            //add new employee
            //var seq = $scope.selectdata_memberteam;
            var seq = $scope.MaxSeqDataMemberteam;

            var newInput = clone_arr_newrow($scope.data_memberteam_def)[0];
            newInput.seq = seq;
            newInput.id = seq;
            newInput.no = (0);
            newInput.id_session = Number(seq_session);
            newInput.action_type = 'insert';
            newInput.action_change = 1;

            newInput.user_name = arr[i].employee_name;
            newInput.user_displayname = arr[i].employee_displayname;
            newInput.user_img = arr[i].employee_img;

            arr_def.push(newInput);

            $scope.MaxSeqDataMemberteam = Number($scope.MaxSeqDataMemberteam) + 1
        }

        var arr_copy_def = angular.copy($scope.data_memberteam, arr_copy_def);
        $scope.data_memberteam = [];
        $scope.data_memberteam = $filter('filter')(arr_copy_def, function (item) {
            return (item.id_session !== seq_session);
        });
        for (let i = 0; i < arr_def.length; i++) {
            $scope.data_memberteam.push(arr_def[i]);
        }

        running_no_level1($scope.data_memberteam, null, null);

        apply();
    };
    $scope.removeDataEmpSession = function (seq, seq_session) {

        var arrdelete = $filter('filter')($scope.data_memberteam, function (item) {
            return (item.seq == seq && item.action_type == 'update');
        });
        if (arrdelete.length > 0) { $scope.data_memberteam_delete.push(arrdelete[0]); }

        $scope.data_memberteam = $filter('filter')($scope.data_memberteam, function (item) {
            return !(item.seq == seq && item.id_session == seq_session);
        });

        running_no_level1($scope.data_memberteam, null, null);
        apply();
    };


    //<==== Free Text  ====>  

    // set mock array 
    $scope.data_Outsider = [];

    const actionTypes = [
        { type: 'attendees', no: 'attendees_no' },
        { type: 'reviewer', no: 'reviewer_no' },
        { type: 'approver', no: 'approver_no' },
        { type: 'specialist', no: 'specialist_no' }
    ];
    
    for (const actionType of actionTypes) {
        const item = {
            outsider_name: null,
            outsider_title: null,
            action_type: actionType.type,
            user_action_type: "Free Text"
        };
    
        item[actionType.no] = 1;
    
        $scope.data_Outsider.push(item);
    }
    
    // Add new row based on action_type
    $scope.addnewFreebox = function (action_type) {
        const property = actionTypes.find(type => type.type === action_type)?.no;

        if (property) {
            // + No. when add new row of the specified action type
            const newRow = {
                outsider_name: null,
                outsider_title: null,
                action_type: action_type,
                user_action_type: "Free Text"
            };
            newRow[property] = $scope.data_Outsider
                .filter(item => item.action_type === action_type)
                .reduce((maxNo, item) => Math.max(maxNo, item[property] || 0), 0) + 1;

            $scope.data_Outsider.push(newRow);
        }
    };
    

    $scope.actionChangeFreetext = function (item,index,action_type) {

        setDataOutsider(item,index,action_type);
    };
    
    function setDataOutsider(item,index,action_type) {

        let outsider_name = item.outsider_name;
        let outsider_title = item.outsider_title;
        let outsider_no = index

        $scope.data_Outsider = $scope.data_Outsider.map(function (item, i) {

            if (i === outsider_no && item.action_type === 'attendees' ) {
                item.outsider_name = outsider_name,
                item.outsider_title =  outsider_title,
                item.action_type =  'attendees',
                item.outsider_no = i+1

            }else if (i === outsider_no && item.action_type === 'reviewer')  {
                item.outsider_name = outsider_name,
                item.outsider_title =  outsider_title,
                action_type = 'reviewer',
                item.outsider_no = i+1

            } else if (i === outsider_no && item.action_type === 'specialist' ) {
                item.outsider_name = outsider_name,
                item.outsider_title =  outsider_title,
                action_type = 'specialist',
                item.outsider_no = i+1

            } else if (i === outsider_no && item.action_type === 'approver' ) {
                item.outsider_name = outsider_name,
                item.outsider_title =  outsider_title,
                action_type = 'approver',
                item.outsider_no = i+1

            } else {
                action_type = '';
            }
            return item;
        });

        console.log( $scope.data_Outsider)
    }

    //<==== Set Main Approver  ====>  
    $scope.setUserTypeMain = function(selectedItem,action_type) {
        selectedItem.isClicked = true;

        if (action_type === 'attendees') {
            selectedItem.user_type_main = 1;
            $scope.data_attendees.forEach(function (item) {
                if (item !== selectedItem) {
                    item.user_type_main = 0;
                    item.isClicked = false;                    
                }
            });
        } else if (action_type === 'reviewer') {
            selectedItem.user_type_main = 1;
            $scope.data_reviewer.forEach(function (item) {
                if (item !== selectedItem) {
                    item.user_type_main = 0;
                    item.isClicked = false;
                }
            });
        } else if (action_type === 'specialist') {
            selectedItem.user_type_main = 1;
            $scope.data_specialist.forEach(function (item) {
                if (item !== selectedItem) {
                    item.user_type_main = 0;
                    item.isClicked = false;
                }
            });
        } else if (action_type === 'approver') {
            selectedItem.user_type_main = 1;
            $scope.data_approver.forEach(function (item) {
                if (item !== selectedItem) {
                    item.user_type_main = 0;
                    item.isClicked = false;
                }
            });
        }
    
    };



    // <==== (Kul)Drawing & Reference zone function  ====>     
    $scope.addDrawingDoc = function (seq, index) {

        $scope.MaxSeqDataDrawingDoc = ($scope.MaxSeqDataDrawingDoc) + 1;
        var xValues = $scope.MaxSeqDataDrawingDoc;

        var arr = $filter('filter')($scope.data_drawing, function (item) { return (item.seq == seq); });
        var iNo = 1; if (arr.length > 0) { iNo = arr[0].no; }

        var newInput = clone_arr_newrow($scope.data_drawing_def)[0];
        newInput.seq = xValues;
        newInput.id = xValues;
        newInput.no = (iNo + 1);
        newInput.action_type = 'insert';
        newInput.action_change = 1;
        console.clear();
        //console.log(newInput);

        running_no_level1_lv1($scope.data_drawing, iNo, index, newInput);

        $scope.selectDrawingDoc = xValues;
        apply();
    }
    $scope.copyDrawingDoc = function (seq, index) {

        $scope.MaxSeqDataDrawingDoc = Number($scope.MaxSeqDataDrawingDoc) + 1;
        var xValues = $scope.MaxSeqDataDrawingDoc;

        var arr = $filter('filter')($scope.data_drawing, function (item) {
            return (item.seq == seq);
        });
        var iNo = 1; if (arr.length > 0) { iNo = arr[0].no; }

        for (let i = 0; i < arr.length; i++) {
            var newInput = clone_arr_newrow($scope.data_drawing_def)[0];
            newInput.seq = Number(xValues);
            newInput.id = Number(xValues);
            newInput.no = (iNo + 1);
            newInput.action_type = 'insert';
            newInput.action_change = 1;
            newInput.document_name = arr[i].document_name;
            newInput.drawing_no = arr[i].drawing_no;
            newInput.document_file = arr[i].document_file;
            newInput.comment = arr[i].comment;
        };
        running_no_level1($scope.data_drawing, iNo, index, newInput);

        $scope.selectDrawingDoc = xValues;
        apply();
    }
    $scope.removeDrawingDoc = function (seq, index) {
        var arrdelete = $filter('filter')($scope.data_drawing, function (item) {
            return (item.seq == seq && item.action_type == 'update');
        });
        if (arrdelete.length > 0) { $scope.data_drawing_delete.push(arrdelete[0]); }

        $scope.data_drawing = $filter('filter')($scope.data_drawing, function (item) {
            return !(item.seq == seq);
        });

        if ($scope.data_drawing.length == 0) {
            $scope.addDrawingDoc();
        }
        running_no_level1($scope.data_drawing, null, index, null);

        apply();
    };


    // <==== Task List zone function  ====>   
    $scope.addDataTaskList = function (seq, index) {

        $scope.MaxSeqDataTaskList = Number($scope.MaxSeqDataTaskList) + 1;
        var xValues = Number($scope.MaxSeqDataTaskList);

        var arr = $filter('filter')($scope.data_task, function (item) { return (item.seq == seq); });
        var iNo = 1; if (arr.length > 0) {
            iNo = arr[0].no;
        }

        var newInput = clone_arr_newrow($scope.data_task_def)[0];
        newInput.seq = xValues;
        newInput.id = xValues;
        newInput.no = (iNo);
        newInput.action_type = 'insert';
        newInput.action_change = 1;
        console.clear();
        //console.log(newInput);

        running_no_level1_lv1($scope.data_task, iNo, index, newInput);

        $scope.selectdata_task = xValues;

        //add TaskDrawing  
        $scope.addDatataskDrawing("", $scope.selectdata_task);

        add_data_listworksheet_new_task(xValues);

        //console.log("addDataTaskList seq:" + $scope.selectdata_task);
        //console.log($scope.data_task);
        //console.log($scope.data_taskdrawing);
        //console.log("data_listworksheet :");
        //console.log($scope.data_listworksheet);

    }

    $scope.copyDataTaskList = function (seq, index) {

        $scope.MaxSeqDataTaskist = Number($scope.MaxSeqDataTaskList) + 1;
        var xValues = Number($scope.MaxSeqDataTaskList);
        var id_list = xValues;

        var arr = $filter('filter')($scope.data_task, function (item) {
            return (item.seq == seq);
        });
        var iNo = 1; if (arr.length > 0) { iNo = arr[0].no; }

        for (let i = 0; i < arr.length; i++) {

            var newInput = clone_arr_newrow($scope.data_task_def)[0];
            newInput.seq = Number(xValues);
            newInput.id = Number(xValues);
            newInput.no = (iNo);
            newInput.action_type = 'insert';
            newInput.action_change = 1;

            newInput.task = arr[i].task;
            newInput.design_intent = arr[i].design_intent;
            newInput.design_conditions = arr[i].design_conditions;
            newInput.operating_conditions = arr[i].operating_conditions;
            newInput.task_boundary = arr[i].task_boundary;
            newInput.task_drawing = arr[i].task_drawing;
        };
        for (let i = (iNo - 1); i < $scope.data_task.length; i++) {
            $scope.data_task[i].no = ($scope.data_task[i].no + 1);
        }

        running_no_level1_lv1($scope.data_task, iNo, index, newInput);

        $scope.selectdata_task = xValues;

        console.clear();
        //console.log(newInput);

        if ($scope.data_taskdrawing != null) {
            var arr_check = $filter('filter')($scope.data_taskdrawing, function (item) {
                return (item.id_list == xValues);
            });
            if (arr_check.length > 0) { return; }
        }
        var arr_copy = [];
        angular.copy($scope.data_taskdrawing, arr_copy);
        var arrmember = $filter('filter')(arr_copy, function (item) { return (item.task == seq); });
        for (let i = 0; i < arrmember.length; i++) {

            $scope.MaxSeqDataTaskDrawing = Number($scope.MaxSeqDataTaskDrawing) + 1;
            var xMaxSeqDataTaskDrawing = $scope.MaxSeqDataTaskDrawing;

            arrmember[i].id_list = Number(id_list);
            arrmember[i].action_type = 'insert';
            arrmember[i].action_change = 1;

            arrmember[i].seq = xMaxSeqDataTaskDrawing;
            arrmember[i].id = xMaxSeqDataTaskDrawing;

            $scope.data_taskdrawing.push(arrmember[i]);
        }

        set_data_listworksheet();
    }
    $scope.removeDataTaskList = function (seq, index) {

        var arrdelete = $filter('filter')($scope.data_task, function (item) {
            return (item.seq == seq && item.action_type == 'update');
        });
        if (arrdelete.length > 0) { $scope.data_task_delete.push(arrdelete[0]); }

        $scope.data_task = $filter('filter')($scope.data_task, function (item) {
            return !(item.seq == seq);
        });

        if ($scope.data_task.length == 0) {
            $scope.addDataTaskList();
        }

        running_no_level1_lv1($scope.data_task, 1, 0, null);


        //delete TaskDrawing
        var arrdelete = $filter('filter')($scope.data_taskdrawing, function (item) {
            return (item.id_list == seq && item.action_type == 'update');
        });
        if (arrdelete.length > 0) { $scope.data_taskdrawing_delete.push(arrdelete[0]); }

        $scope.data_taskdrawing = $filter('filter')($scope.data_taskdrawing, function (item) {
            return !(item.id_list == seq);
        });
        if ($scope.data_taskdrawing.length == 0) {
            $scope.MaxSeqDataTaskDrawing = Number($scope.MaxSeqDataTaskDrawing) + 1;
            $scope.addDataTaskDrawing($scope.MaxSeqDataTaskDrawing, seq);
        }

    };


    // <==== TaskDrawing zone function  ====>
    $scope.addDataTaskDrawing = function (seq, seq_list) {

        $scope.MaxSeqDataTaskDrawing = Number($scope.MaxSeqDataTaskDrawing) + 1;
        var xValues = $scope.MaxSeqDataTaskDrawing;

        var arr = $filter('filter')($scope.data_taskdrawing, function (item) {
            return (item.seq == seq && item.id_list == seq_list);
        });
        var iNo = 1; if (arr.length > 0) { iNo = arr[0].no; }

        var newInput = clone_arr_newrow($scope.data_taskdrawing_def)[0];
        newInput.seq = xValues;
        newInput.id = xValues;
        newInput.no = (iNo + 1);
        newInput.id_list = Number(seq_list);
        newInput.seq_list = Number(seq_list);

        newInput.action_type = 'insert';
        newInput.action_change = 1;

        //console.log(newInput);

        $scope.data_taskdrawing.push(newInput);

    };
    $scope.removeDataTaskDrawing = function (seq, seq_list) {

        var arrdelete = $filter('filter')($scope.data_taskdrawing, function (item) {
            return (item.seq == seq && item.action_type == 'update');
        });
        if (arrdelete.length > 0) { $scope.data_taskdrawing_delete.push(arrdelete[0]); }

        $scope.data_taskdrawing = $filter('filter')($scope.data_taskdrawing, function (item) {
            return !(item.seq == seq);
        });

        if ($scope.data_taskdrawing.length == 0) {
            $scope.MaxSeqDataTaskList = Number($scope.MaxSeqDataTaskList) + 1;
            $scope.addDataTaskDrawing($scope.MaxSeqDataTaskDrawing, seq_list);
        }
    };
    $scope.updateDataTaskDrawing = function (seq, seq_list, seq_drawing) {

        var arr_def = $filter('filter')($scope.data_taskdrawing, function (item) {
            return (item.seq == seq && item.id_list == seq_list);
        });
        if (arr_def.length > 0) {
            arr_def[0].id_drawing = Number(seq_drawing);
            apply();
        }

    };    



    $scope.openModalNewRAM = function (seq) {

        $('#modalNewRAM').modal('show');
    };
    $scope.confirmAddRAM = function () {
        $('#modalNewRAM').modal('show');
        //$scope.ram_rows_level = 4;
        //$scope.ram_columns_level = 4;

        //check data in maste_ram  
        var arr = $filter('filter')($scope.master_ram, function (item) {
            return (item.ram_rows_level == Number($scope.ram_rows_level) && item.ram_columns_level == Number($scope.ram_columns_level));
        });
        if (arr.length > 0) {
            $scope.ram_msg_level = 'Risk Assessment Matrix data is already in the system';
            var id_ram = Number(arr[0].id);
            $scope.data_general[0].id_ram = id_ram;
            apply();

            $('#modalNewRAM').modal('hide');
            return;
        }

        if (true) {
            //seq, id, name, descriptions, active_type, category_type, document_file_name, document_file_path
            var newInput = clone_arr_newrow($scope.master_ram)[0];
            newInput.seq = Number(0);
            newInput.id = Number(0);
            newInput.active_type = 1;
            newInput.category_type = 0;
            newInput.document_file_name = null;
            newInput.document_file_path = null;

            newInput.ram_rows_level = Number($scope.ram_rows_level);
            newInput.ram_columns_level = Number($scope.ram_columns_level);

            newInput.name = $scope.ram_rows_level + 'x' + $scope.ram_columns_level;
            newInput.descriptions = 'Risk Assessment Matrix :' + $scope.ram_rows_level + 'x' + $scope.ram_columns_level;

            newInput.action_change = 1;
            newInput.action_type = 'insert'
            $scope.master_ram.push(newInput);
        }
        var json_ram_master = angular.toJson($scope.master_ram);;

        $.ajax({
            url: url_ws + "Flow/set_master_ram",
            data: '{"user_name":"' + user_name + '"'
                + ',"json_ram_master":' + JSON.stringify(json_ram_master)
                + '}',
            type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
            beforeSend: function () {
                $("#divLoading").show();
            },
            complete: function () {
                $("#divLoading").hide();
            },
            success: function (data) {
                var arr = data;
                //console.log(arr);
                if (arr.msg[0].status == 'true') {

                    //แก้ไขเบื้องต้น เนื่องจาก path file ผิดต้องเป็น folder whatif
                    for (let i = 0; i < arr.ram.length; i++) {
                        arr.ram[i].document_file_path = (url_ws.replace('/api/', '/')) + arr.ram[i].document_file_path;
                    }
                    $scope.master_ram = arr.ram;
                    $scope.master_ram_level = arr.ram_level;
                    $scope.master_security_level = arr.security_level;
                    $scope.master_likelihood_level = arr.likelihood_level;

                    var arr = $filter('filter')($scope.master_ram, function (item) {
                        return (item.ram_rows_level == Number($scope.ram_rows_level) && item.ram_columns_level == Number($scope.ram_columns_level));
                    });
                    if (arr.length > 0) {
                        var id_ram = Number(arr[0].id);
                        $scope.data_general[0].id_ram = id_ram;
                        set_master_ram_likelihood(id_ram);
                    }
                    apply();

                    $('#modalNewRAM').modal('hide');
                } else {
                    $scope.ram_msg_level = arr.msg[0].status;
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    alert('Internal error: ' + jqXHR.responseText);
                } else {
                    alert('Unexpected ' + textStatus);
                }
            }

        });

    };


    // <==== (Kul) WorkSheet zone function  ====>  
    $scope.DataCategory = [{ id: "P", name: "P", description: "People" },
    { id: "A", name: "A", description: "Assets" },
    { id: "E", name: "E", description: "Environment" },
    { id: "R", name: "R", description: "Reputation" },
    { id: "Q", name: "Q", description: "Product Quality" },];


    //$scope.data_taskView = [{ no: 1, seq: 1, task_text: '', design_intent: '', design_conditions: '', operating_conditions: '', task_boundary: '', task_drawing: '' },];
    $scope.viewDataTaskList = function (seq) {
        $scope.selectedItemTaskeView = seq;
        //set_data_listworksheet();
        //apply();
    };


 

    $scope.adddata_listworksheet_lv1 = function (row_type, item, index) {
        if (row_type.indexOf('list_system') > -1) { row_type = 'list_system'; }
        else if (row_type.indexOf('list_sub_system') > -1) { row_type = 'list_sub_system'; }
        else if (row_type.indexOf('causes') > -1) { row_type = 'causes'; }        
        else if (row_type.indexOf('consequences') > -1) { row_type = 'consequences'; }
        else if (row_type.indexOf('category ') > -1) { row_type = 'category '; }

        console.log(item)

        var seq = item.seq;
        var seq_list_system = item.seq_list_system;
        var seq_list_sub_system = item.seq_list_sub_system;
        var seq_causes = item.seq_causes;
        var seq_consequences = item.seq_consequences;
        var seq_cat = item.seq_cat;

        var no = Number(item.no);
        var list_system_no = Number(item.list_system_no);
        var list_sub_system_no = Number(item.list_sub_system_no);
        var causes_no = Number(item.causes_no);
        var consequences_no = Number(item.consequences_no);
        var category_no = Number(item.category_no);


        //row now
        var iNo = no;
        if (row_type == "list_system") {
            var arr = $filter('filter')($scope.data_listworksheet, function (_item) {
                return (_item.no >= no && _item.seq_list_system == seq_list_system);
            });
            if (arr.length > 0) {
                arr.sort((a, b) => a.no - b.no);
                iNo = arr[arr.length - 1].no;
            }
        } else if (row_type == "listsub") {
            var arr = $filter('filter')($scope.data_listworksheet, function (_item) {
                return (_item.no >= no && _item.seq_list_system == seq_list_system && _item.seq_list_sub_system == seq_list_sub_system);
            });
            if (arr.length > 0) { iNo = arr[arr.length - 1].no; }
        } else if (row_type == "causes") {
            var arr = $filter('filter')($scope.data_listworksheet, function (_item) {
                return (_item.no >= no && _item.seq_list_system == seq_list_system && _item.seq_list_sub_system == seq_list_sub_system && _item.seq_causes == seq_causes);
            });
            if (arr.length > 0) { iNo = arr[arr.length - 1].no; }
        } else if (row_type == "consequences") {
            var arr = $filter('filter')($scope.data_listworksheet, function (_item) {
                return (_item.no >= no && _item.seq_list_system == seq_list_system && _item.seq_list_sub_system == seq_list_sub_system && _item.seq_causes == seq_causes
                    && _item.seq_consequences == seq_consequences);
            });
            if (arr.length > 0) { iNo = arr[arr.length - 1].no; }
        } else if (row_type == "category") {
            var arr = $filter('filter')($scope.data_listworksheett, function (_item) {
                return (_item.no >= no && _item.seq_list_system == seq_list_system && _item.seq_list_sub_system == seq_list_sub_system && _item.seq_causes == seq_causes
                    && _item.seq_consequences == seq_consequences && _item.seq_cat == seq_cat);
            });
            if (arr.length > 0) { iNo = arr[arr.length - 1].no; }
        }


    $scope.MaxSeqdata_listworksheet = Number($scope.MaxSeqdata_listworksheet) + 1;
        var xseq = $scope.MaxSeqdata_listworksheet;

        if (row_type == "list_system") {
            $scope.MaxSeqdata_listworksheetlist = Number($scope.MaxSeqdata_listworksheetlist) + 1;
            seq_list_system = $scope.MaxSeqdata_listworksheetlist;

            //กรณีที่เป็น list ให้ +1 
            list_system_no += 1;
            list_sub_system_no = 1;
            causes_no = 1;
            consequences_no = 1;
            category_no = 1;
        }
        if (row_type == "list_sub_system") {
            $scope.MaxSeqdata_listworksheetlistsub = Number($scope.MaxSeqdata_listworksheetlistsub) + 1;
            seq_list_sub_system = $scope.MaxSeqdata_listworksheetlistsub;

            //กรณีที่เป็น listsub ให้ +1
            list_sub_system_no += 1;
            causes_no = 1;
            consequences_no = 1;
            category_no = 1;
        }
        if (row_type == "causes") {
            $scope.MaxSeqdata_listworksheetcauses = Number($scope.MaxSeqdata_listworksheetcauses) + 1;
            seq_causes = $scope.MaxSeqdata_listworksheetcauses;

            //กรณีที่เป็น causes ให้ +1
            causes_no -= 1;
            consequences_no = 1;
            category_no = 1;
        }
        if (row_type == "consequences") {
            $scope.MaxSeqdata_listworksheetconsequences = Number($scope.MaxSeqdata_listworksheetconsequences) + 1;
            seq_consequences = $scope.MaxSeqdata_listworksheetconsequences;

            //กรณีที่เป็น  consequences ให้ +
            consequences_no += 1;
            category_no = 1;
        }
        if (row_type == "category") {
            $scope.MaxSeqdata_listworksheetcategory = Number($scope.MaxSeqdata_listworksheetcategory) + 1;
            category = $scope.MaxSeqdata_listworksheetcategory;

            //กรณีที่เป็น cat ให้ +1
            category_no += 1;
        }

        var newInput = clone_arr_newrow($scope.data_listworksheet_def)[0];
        newInput.seq = xseq;
        newInput.id = xseq;

        newInput.row_type = row_type;

        newInput.seq_list_system = seq_list_system;
        newInput.seq_list_sub_system = seq_list_sub_system;
        newInput.seq_causes = seq_causes;
        newInput.seq_consequences = seq_consequences;
        newInput.seq_cat = seq_cat;

        newInput.no = no;
        newInput.list_system_no = list_system_no;
        newInput.list_sub_system_no = list_sub_system_no;
        newInput.causes_no = causes_no;
        newInput.consequences_no = consequences_no;
        newInput.category_no = category_no;

        //newInput.recommendations_no = recommendations_no; 
        newInput.row_type = row_type;

        newInput.action_type = 'insert';
        newInput.action_change = 1;
        newInput.action_status = 'Open';

        $scope.selectdata_listworksheet = xseq;


        //console.clear();
        //console.log('data_listworksheet');
        //console.log($scope.data_listworksheet);

        index = (iNo - 1);
        running_no_level1_lv1($scope.data_listworksheet, iNo, index, newInput);

        if (row_type == "list" || row_type == "listsub" || true) {
            //list,listsub,causes,possiblecase,category
            running_no_list();
            running_no_listsub(seq_list_system);
            running_no_causes(seq_list_system, seq_list_sub_system);
            running_no_consequences(seq_list_system, seq_list_sub_system, seq_causes);

        } else if (row_type == "category") {
            //not running
        }

        apply();
    }


    $scope.removeDataworksheet = function (row_type, item, index) {

        var seq = item.seq;
        var seq_list_system = item.seq_list_system;
        var seq_list_sub_system = item.seq_list_sub_system;
        var seq_causes = item.seq_causes;
        var seq_consequences = item.seq_consequences;

        //กรณีที่เป็นรายการเดียวไม่ต้องลบ ให้ cleare field 
        var arrCheck = [];
        if (true) {
            if (row_type == "list") {
                var arrCheck = $filter('filter')($scope.data_listworksheet, function (_item) {
                    return (true);
                });
            } else if (row_type == "listsub") {
                var arrCheck = $filter('filter')($scope.data_listworksheet, function (_item) {
                    return (_item.seq_list_system == seq_list_system);
                });
            } else if (row_type == "causes") {
                var arrCheck = $filter('filter')($scope.data_listworksheet, function (_item) {
                    return (_item.seq_list_system == seq_list_system & _item.seq_list_sub_system == seq_list_sub_system);
                });
            } else if (row_type == "consequences") {
                var arrCheck = $filter('filter')($scope.data_listworksheet, function (_item) {
                    return (_item.seq_list_system == seq_list_system & _item.seq_list_sub_system == seq_list_sub_system & _item.seq_causes  == seq_causes );
                });
            } else if (row_type == "category") {
                var arrCheck = $filter('filter')($scope.data_listworksheet, function (_item) {
                    return (_item.seq_list_system == seq_list_system & _item.seq_list_sub_system == seq_list_sub_system & _item.seq_causes  == seq_causes  & _item.seq_consequences == seq_consequences);
                });
            }
        }
        if (arrCheck.length == 1) {
            //กรณีที่เหลือ row เดียว  
            arrCheck[0].action_type = 'update';
            arrCheck[0].action_change = 1;
            arrCheck[0].action_status = 'Open';

            arrCheck[0].list = null;
            arrCheck[0].listsub = null;
            arrCheck[0].causes = null;
            arrCheck[0].consequences = null;

            arrCheck[0].category_type = null;

            arrCheck[0].ram_befor_security = null;
            arrCheck[0].ram_befor_likelihood = null;
            arrCheck[0].ram_befor_risk = null;
            arrCheck[0].major_accident_event = null;
            arrCheck[0].safety_critical_equipment = null;
            arrCheck[0].safeguard_mitigation = null;
            arrCheck[0].ram_after_security = null;
            arrCheck[0].ram_after_likelihood = null;
            arrCheck[0].ram_after_risk = null;
            arrCheck[0].recommendations = null;

            arrCheck[0].responder_user_id = null;
            arrCheck[0].responder_user_name = null;
            arrCheck[0].responder_user_email = null;
            arrCheck[0].responder_user_displayname = null;
            arrCheck[0].responder_user_img = null;

            arrCheck[0].row_type = row_type == "list";
            apply();
            return;
        }


        var arrdelete = $filter('filter')($scope.data_listworksheet, function (item) {
            return (item.seq == seq && item.action_type == 'update');
        });
        if (arrdelete.length > 0) { $scope.data_listworksheet_delete.push(arrdelete[0]); }

        $scope.data_listworksheet = $filter('filter')($scope.data_listworksheet, function (item) {
            return !(item.seq == seq);
        });

        running_no_level1_lv1($scope.data_listworksheet, 1, 0, null);
        if (row_type == "list") {
            running_no_list();
        } else if (row_type == "listsub") {
            running_no_list();
            running_no_listsub(seq_list_system);
        }
    };

    $scope.removedata_listworksheet = function (seq) {

        $scope.data_listworksheet = $filter('filter')($scope.data_listworksheet, function (item) {
            return !(item.seq == seq);
        });

        var arrdelete = $filter('filter')($scope.data_listworksheet, function (item) {
            return (item.seq == seq && item.action_type == 'update');
        });
        if (arrdelete.length > 0) { $scope.data_listworksheet_delete.push(arrdelete[0]); }

        $scope.data_listworksheet = $filter('filter')($scope.data_listworksheet, function (item) {
            return !(item.seq == seq);
        });
        if ($scope.data_listworksheet.length == 0) {
            $scope.adddata_listworksheet_lv1('category', item)
        }


        running_no_level1_lv1($scope.data_listworksheet, iNo, index, newInput);
        if (row_type == "list") {
            running_no_list();
        } else if (row_type == "listsub") {
            running_no_list();
            running_no_listsub(seq_list_system);
        }
    };

    function running_no_list() {
        var arr_items = $filter('filter')($scope.data_listworksheet, function (item) {
            return ((item.row_type == 'list'));
        });
        arr_items.sort((a, b) => a.no - b.no);
        var first_row = true;
        var iNoNew = 1;

        for (let i = 0; i < arr_items.length; i++) {
            arr_items[i].list_system_no = (iNoNew);
            iNoNew++;
            if (i == 0) { arr_items[i].row_type == 'list'; }
            else { arr_items[i].row_type == ''; }
        };

        arr_items.sort((a, b) => a.list_system_no - b.list_system_no);

        arr_items = $filter('filter')($scope.data_listworksheet, function (item) {
            return (true);
        });

        var bfor = ''; var after = ''; iNoNew = 1;
        for (let i = 0; i < arr_items.length; i++) {
            arr_items[i].no = (iNoNew);
            iNoNew++;
        };
    }
    function running_no_listsub(seq_list_system) {
        //row_type;//list,listsub,causes,consequences        
        var arr_items = $filter('filter')($scope.data_listworksheet, function (item) {
            return (item.seq_list_system == seq_list_system
                && (item.row_type == 'list' || item.row_type == 'listsub'));
        });
        arr_items.sort((a, b) => a.no - b.no);
        var first_row = true;
        var iNoNew = 1;

        for (let i = 0; i < arr_items.length; i++) {
            arr_items[i].list_sub_system_no = (iNoNew);
            iNoNew++;
        };
        arr_items.sort((a, b) => a.list_sub_system_no - b.list_sub_system_no);
    }    
    function running_no_causes(seq_list_system, seq_list_sub_system) {
        //row_type;//list,listsub,causes,consequences
        var arr_items = $filter('filter')($scope.data_listworksheet, function (item) {
            return (item.seq_list_system == seq_list_system
                && item.seq_list_sub_system == seq_list_sub_system
                && (item.row_type == 'list' || item.row_type == 'listsub' || item.row_type == 'causes'));
        });
        arr_items.sort((a, b) => a.no - b.no);
        var first_row = true;
        var iNoNew = 1;

        for (let i = 0; i < arr_items.length; i++) {
            arr_items[i].causes_no = (iNoNew);
            iNoNew++;
        };
        arr_items.sort((a, b) => a.causes_no - b.causes_no);
    }
    function running_no_consequences(seq_list_system, seq_list_sub_system, seq_causes) {
        //row_type;//list,listsub,causes,consequences
        var arr_items = $filter('filter')($scope.data_listworksheet, function (item) {
            return (item.seq_list_system == seq_list_system
                && item.seq_list_sub_system == seq_list_sub_system
                && item.seq_causes == seq_causes
                && (item.row_type == 'list' || item.row_type == 'listsub' || item.row_type == 'causes' || item.row_type == 'consequences'));
        });
        arr_items.sort((a, b) => a.no - b.no);
        var first_row = true;
        var iNoNew = 1;

        for (let i = 0; i < arr_items.length; i++) {
            arr_items[i].consequences_no = (iNoNew);
            iNoNew++;
        };
        arr_items.sort((a, b) => a.consequences_no - b.consequences_no);
    }


    $scope.openModalDataRAM = function (ram_type, seq, ram_type_action) {

        $scope.selectdata_listworksheet = seq;
        $scope.selectedDataListworksheetRamType = ram_type;
        $scope.selectedDataRamTypeAction = ram_type_action;

        $('#modalRAM').modal('show');
    }
    $scope.openModalDataNotification = function (item) {
        //modalNotification

        //item.id_apu 
        $('#modalNotification').modal('show');
    }
    $scope.selectDataRAM = function (ram_type, id_select) {

        var xseq = $scope.selectdata_listworksheet;
        var xbefor = $scope.selectedDataRamTypeAction;

        for (let i = 0; i < $scope.data_listworksheet.length; i++) {
            try {

                if ($scope.data_listworksheet[i].seq !== xseq) { continue; }

                if (xbefor == "befor" && ram_type == "s") { $scope.data_listworksheet[i].ram_befor_security = id_select; }
                if (xbefor == "befor" && ram_type == "l") { $scope.data_listworksheet[i].ram_befor_likelihood = id_select; }

                if (xbefor == "after" && ram_type == "s") { $scope.data_listworksheet[i].ram_after_security = id_select; }
                if (xbefor == "after" && ram_type == "l") { $scope.data_listworksheet[i].ram_after_likelihood = id_select; }

                var ram_security = $scope.data_listworksheet[i].ram_befor_security + "";
                var ram_likelihood = $scope.data_listworksheet[i].ram_befor_likelihood + "";
                var ram_risk = "";
                if (xbefor == "after") {
                    ram_security = $scope.data_listworksheet[i].ram_after_security + "";
                    ram_likelihood = $scope.data_listworksheet[i].ram_after_likelihood + "";
                }
                if (ram_security == "" || ram_likelihood == "") {
                    if (xbefor == "befor") { $scope.data_listworksheet[i].ram_befor_risk = ""; }
                    else { $scope.data_listworksheet[i].ram_after_risk = ""; }
                    break;
                }


                var safety_critical_equipment = 'N';
                //master_ram_level  | filter:{id_ram:data_general[0].id_ram}
                var id_ram = $scope.data_general[0].id_ram;
                var arr_items = $filter('filter')($scope.master_ram_level, function (item) {
                    return (item.id_ram == id_ram && item.security_level == ram_security);
                });
                if (arr_items.length > 0) {
                    //check ram_likelihood ว่าตก columns ไหน เพื่อหา ram1_priority
                    if (ram_likelihood == arr_items[0].likelihood1_level) { ram_risk = arr_items[0].ram1_priority; safety_critical_equipment = arr_items[0].likelihood1_criterion; }
                    else if (ram_likelihood == arr_items[0].likelihood2_level) { ram_risk = arr_items[0].ram2_priority; safety_critical_equipment = arr_items[0].likelihood2_criterion; }
                    else if (ram_likelihood == arr_items[0].likelihood3_level) { ram_risk = arr_items[0].ram3_priority; safety_critical_equipment = arr_items[0].likelihood3_criterion; }
                    else if (ram_likelihood == arr_items[0].likelihood4_level) { ram_risk = arr_items[0].ram4_priority; safety_critical_equipment = arr_items[0].likelihood4_criterion; }
                    else if (ram_likelihood == arr_items[0].likelihood5_level) { ram_risk = arr_items[0].ram5_priority; safety_critical_equipment = arr_items[0].likelihood5_criterion; }
                    else if (ram_likelihood == arr_items[0].likelihood6_level) { ram_risk = arr_items[0].ram6_priority; safety_critical_equipment = arr_items[0].likelihood6_criterion; }
                    else if (ram_likelihood == arr_items[0].likelihood7_level) { ram_risk = arr_items[0].ram7_priority; safety_critical_equipment = arr_items[0].likelihood7_criterion; }
                    else if (ram_likelihood == arr_items[0].likelihood8_level) { ram_risk = arr_items[0].ram8_priority; safety_critical_equipment = arr_items[0].likelihood8_criterion; }
                    else if (ram_likelihood == arr_items[0].likelihood9_level) { ram_risk = arr_items[0].ram9_priority; safety_critical_equipment = arr_items[0].likelihood9_criterion; }
                    else if (ram_likelihood == arr_items[0].likelihood10_level) { ram_risk = arr_items[0].ram10_priority; safety_critical_equipment = arr_items[0].likelihood10_criterion; }
                }
                //item.safety_critical_equipment
                if (xbefor == "befor" && (ram_type == "s" || ram_type == "l")) {
                    $scope.data_listworksheet[i].safety_critical_equipment = safety_critical_equipment;
                }

                if (xbefor == "befor") { $scope.data_listworksheet[i].ram_befor_risk = ram_risk; }
                else { $scope.data_listworksheet[i].ram_after_risk = ram_risk; }

                if ($scope.data_listworksheet[i].action_type == 'update') {
                    $scope.data_listworksheet[i].action_change = 1;
                }


                $scope.actionChangeWorksheet($scope.data_listworksheet[i], $scope.data_listworksheet[i].seq);
                break;

            } catch (e) { }
        }


        $('#modalRAM').modal('hide');
    }

    $scope.openModalDataEmployee = function (form_type, seq) {
        //openModalDataEmployee('info', item.seq)
        $scope.selectDatFormType = form_type;
        $scope.selectdata_listworksheet = seq;

        $('#modalEmployeeSelect').modal('show');
    }
    $scope.selectDataEmployee = function (item) {

        var id = item.id;
        var employee = item.employee_name;
        var employee_display = item.employee_displayname;
        var employee_email = item.employee_email;
        var profile = item.employee_img;

        var xseq = $scope.selectdata_listworksheet;
        var xformtype = $scope.selectDatFormType;

        $scope.DataMain = [];

        // alert(xformtype);
        if (xformtype == "info") {
            // กรณีที่เลือก approver ta2
            // approve_action_type, approve_status, approver_user_name, approver_user_displayname 
            $scope.data_header[0].approver_user_name = employee;
            $scope.data_header[0].approver_user_displayname = employee_display;

        } else {

            var arr_items = $filter('filter')($scope.data_listworksheet, function (item) { return (item.seq == xseq); })[0];

            arr_items.responder_user_id = id;
            arr_items.responder_user_name = employee;
            arr_items.responder_user_displayname = employee_display;
            arr_items.responder_user_email = employee_email;
            arr_items.responder_user_img = profile;

            $scope.actionChangeWorksheet(arr_items, arr_items.seq);
        }
        apply();
        $('#modalEmployeeSelect').modal('hide');
    };

    $scope.removeDataEmpApprover = function () {
        $scope.data_header[0].approver_user_name = null;
        $scope.data_header[0].approver_user_displayname = null;
        apply();
    };
    $scope.removeDataEmpWorkSheet = function (form_type, id, seq) {
        var xseq = seq;
        var xformtype = $scope.selectDatFormType;

        if (xformtype == "info") {
            $scope.DataMain = [];
        } else {
            for (let i = 0; i < $scope.data_listworksheet.length; i++) {
                try {
                    if ($scope.data_listworksheet[i].seq == xseq) {
                        $scope.data_listworksheet[i].responder_user_id = null;
                        $scope.data_listworksheet[i].responder_user_name = null;
                        $scope.data_listworksheet[i].responder_user_displayname = null;
                        $scope.data_listworksheet[i].responder_user_email = null;
                        $scope.data_listworksheet[i].responder_user_img = null;
                        break;
                    }
                } catch (e) { }
            };
        }
    };
    $scope.zoom_div_worksheet = function (a) {

        var el = document.getElementById('WorksheetTable');
        if (a == "in") {

            el.style.zoom = 1;
            return;
        }
        if (document.fullscreenElement) {
            document.exitFullscreen();
            el.style.zoom = 0;
        } else {
            $('#WorksheetTable').get(0).requestFullscreen();

            el.style.zoom = 0.7;
            el.style.backgroundColor = "white";
        }


    };

    $scope.selectMemberTeamCalendar = false;

    $scope.ViewMemberTeamCalendar = function () {
        $scope.selectMemberTeamCalendar = !$scope.selectMemberTeamCalendar;
    };
    $scope.addText = function () {
        // var newText = {a:$scope.inputTextA,b:$scope.inputTextB,c:$scope.inputTextC}; 
        var newText1 = $scope.employee_displayname;
        var newText2 = $scope.employee_email;
        var newText3 = 'Vender';
        // var newText4 = $scope.Section;


        // ตรวจสอบค่าว่างของทั้งสอง input
        if (newText1 == '' || newText2 == '' || newText3 == '') {
            // หยุดการเพิ่มข้อมูลเนื่องจากมีค่าว่าง
            return;
        }

        var emprow = {
            employee_id: $scope.employeelist.length + 1,
            employee_displayname: newText1,
            employee_email: newText2
            , employee_type: 'Contract'
            , employee_img: 'assets/img/team/avatar.webp'
            , selected: false
            , seq: 0
        };

        // เพิ่มข้อความลงในแถวของตาราง
        $scope.employeelist.unshift(emprow);


    };

    $scope.Attendees = [];

    $scope.showSelectedData = function () {
        $scope.Attendees = $scope.employeelist.filter(function (item) {
            return item.selected;
        });
    };

    $scope.removeItem = function (item) {
        var index = $scope.Attendees.indexOf(item);
        if (index !== -1) {
            $scope.Attendees.splice(index, 1);
        }
    };
    $scope.Specialist = [];

    $scope.showSelectedDataSpecialist = function () {
        $scope.Specialist = $scope.employeelist.filter(function (list) {
            return list.selected;
        });
    };

    $scope.removeItemSpecialist = function (list) {
        var index = $scope.Specialist.indexOf(list);
        if (index !== -1) {
            $scope.Specialist.splice(index, 1);
        }
    };
    $scope.selectReviewer = function (item) {
        $scope.selectedDataReviewer = item;
    }

    $scope.clearReviewer = function (item) {
        $scope.selectedDataReviewer = null;
    }


    $scope.selectApprover = function (item) {
        $scope.selectedDataApprover = item;
    }

    $scope.clearApprover = function (item) {
        $scope.selectedDataApprover = null;
    }
    $scope.safety_critical_equipment_show = function () {

        if ($scope.data_header[0].safety_critical_equipment_show == 1) {
            $scope.data_header[0].safety_critical_equipment_show = 0;
        } else if ($scope.data_header[0].safety_critical_equipment_show == 0) {
            $scope.data_header[0].safety_critical_equipment_show = 1
        } else {
            $scope.data_header[0].safety_critical_equipment_show = 1;
        }

        var inputs = document.getElementsByTagName('sceSwitchCheckChecked');
        for (var i = 0; i < inputs.length; i++) {
            if (inputs[i].type == 'checkbox') {
                if ($scope.data_header[0].safety_critical_equipment_show == 1) {
                    inputs[i].checked = true;
                } else { inputs[i].checked = false; }
            }
        }

        if ($scope.data_header[0].safety_critical_equipment_show == 1) {

            for (var i = 0; i < $scope.data_listworksheet.length; i++) {

                var safety_critical_equipment = $scope.data_listworksheet[i].safety_critical_equipment;
                if (safety_critical_equipment == null) { safety_critical_equipment = ''; }
                if (safety_critical_equipment == '') {

                    var id_ram = $scope.data_general[0].id_ram;
                    var ram_security = $scope.data_listworksheet[i].ram_befor_security;
                    var ram_likelihood = $scope.data_listworksheet[i].ram_befor_likelihood;
                    var arr_items = $filter('filter')($scope.master_ram_level, function (item) {
                        return (item.id_ram == id_ram && item.security_level == ram_security);
                    });
                    if (arr_items.length > 0) {
                        //check ram_likelihood ว่าตก columns ไหน เพื่อหา ram1_priority
                        if (ram_likelihood == arr_items[0].likelihood1_level) { safety_critical_equipment = arr_items[0].likelihood1_criterion; }
                        else if (ram_likelihood == arr_items[0].likelihood2_level) { safety_critical_equipment = arr_items[0].likelihood2_criterion; }
                        else if (ram_likelihood == arr_items[0].likelihood3_level) { safety_critical_equipment = arr_items[0].likelihood3_criterion; }
                        else if (ram_likelihood == arr_items[0].likelihood4_level) { safety_critical_equipment = arr_items[0].likelihood4_criterion; }
                        else if (ram_likelihood == arr_items[0].likelihood5_level) { safety_critical_equipment = arr_items[0].likelihood5_criterion; }
                        else if (ram_likelihood == arr_items[0].likelihood6_level) { safety_critical_equipment = arr_items[0].likelihood6_criterion; }
                        else if (ram_likelihood == arr_items[0].likelihood7_level) { safety_critical_equipment = arr_items[0].likelihood7_criterion; }
                        else if (ram_likelihood == arr_items[0].likelihood8_level) { safety_critical_equipment = arr_items[0].likelihood8_criterion; }
                        else if (ram_likelihood == arr_items[0].likelihood9_level) { safety_critical_equipment = arr_items[0].likelihood9_criterion; }
                        else if (ram_likelihood == arr_items[0].likelihood10_level) { safety_critical_equipment = arr_items[0].likelihood10_criterion; }
                    }
                    $scope.data_listworksheet[i].safety_critical_equipment = safety_critical_equipment;
                }
            }
        }
        apply();
    }


    $scope.isFullscreen = false;

    $scope.toggleFullscreen = function () {
        var element = document.getElementById('fullscreenzone');

        if (!document.fullscreenElement && !document.webkitFullscreenElement && !document.mozFullScreenElement && !document.msFullscreenElement) {
            if (element.requestFullscreen) {
                element.requestFullscreen();
            } else if (element.mozRequestFullScreen) {
                element.mozRequestFullScreen();
            } else if (element.webkitRequestFullscreen) {
                element.webkitRequestFullscreen();
            } else if (element.msRequestFullscreen) {
                element.msRequestFullscreen();
            }

            $scope.isFullscreen = true;

            element.style.overflow = 'auto';
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            } else if (document.mozCancelFullScreen) {
                document.mozCancelFullScreen();
            } else if (document.msExitFullscreen) {
                document.msExitFullscreen();
            }

            $scope.isFullscreen = false;

            element.style.overflow = 'hidden';
        }
    };

    document.addEventListener('keydown', $scope.handleKeydown);

    $scope.handleKeydown = function (event) {
        if (event.key == 'F11') {
            event.preventDefault();
            $scope.toggleFullscreen();
        }
    };

    $scope.$on('$destroy', function () {
        document.removeEventListener('keydown', $scope.handleKeydown);
    });


    $scope.startPage = 1;
    $scope.pdfUrl = 'http://www.thapra.lib.su.ac.th/m-talk/attachments/article/75/ebook.pdf';
    // $scope.pdfUrl = 'http://127.0.0.1:5500/public/assets/pdf/test.pdf';
    $scope.embedPdf = function (_item) {
        // find in data_drawing
        // page_start_first,page_start_second,page_end_first,page_end_second

        var arr_drawing = $filter('filter')($scope.data_drawing, function (item) {
            return ((item.id == _item.id_drawing));
        });
        if (arr_drawing.length == 0) { return; }

        var file_name = arr_drawing[0].document_file_name;
        var file_path = arr_drawing[0].document_file_path;

        var page_start_first = _item.page_start_first;
        var page_start_second = _item.page_start_second;
        var page_end_first = _item.page_end_first;
        var page_end_second = _item.page_end_second;

        $.ajax({
            url: url_ws + "Flow/copy_pdf_file",
            data: '{"file_name":"' + file_name + '","file_path":"' + file_path + '"'
                + ',"page_start_first":"' + page_start_first + '","page_start_second":"' + page_start_second + '"'
                + ',"page_end_first":"' + page_end_first + '","page_end_second":"' + page_end_second + '"'
                + '}',
            type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
            beforeSend: function () {
                //$('#modalLoadding').modal('show');
                $('#divLoading').show();
            },
            complete: function () {
                //$('#modalLoadding').modal('hide');
                $('#divLoading').hide();
            },
            success: function (data) {
                var arr = data;
                //console.log(arr);
                if (arr.length > 0) {
                    if (arr[0].ATTACHED_FILE_NAME != '') {
                        var path = (url_ws).replace('/api/', '') + arr[0].ATTACHED_FILE_PATH;
                        var name = arr[0].ATTACHED_FILE_NAME;
                        $scope.exportfile[0].DownloadPath = path;
                        $scope.exportfile[0].Name = name;

                        $('#modalExportFile').modal('show');
                        //$('#modalLoadding').modal('hide'); 
                        $('#divLoading').hide();
                        apply();
                    }
                } else {
                    set_alert('Error', arr[0].IMPORT_DATA_MSG);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    alert('Internal error: ' + jqXHR.responseText);
                } else {
                    alert('Unexpected ' + textStatus);
                }
            }

        });

    };
    $scope.formData = {};

    $scope.confirmBack = function () {

        window.open("home/portal", "_top");

        return;
        //var page = conFig.controller_action_befor();
        //conFig.pha_seq = null;
        //conFig.pha_type_doc = '';
        //window.open(page, "_top")

        var pha_type_doc = 'back';
        var pha_status = "";

        var page = conFig.controller_action_befor();
        var controller_text = "whatif";
        conFig.pha_seq = null;
        conFig.pha_type_doc = pha_type_doc;

        $.ajax({
            url: controller_text + "/next_page",
            data: '{"controller_action_befor":"' + page + '","pha_type_doc":"' + pha_type_doc + '"}',
            type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
            beforeSend: function () {
                $("#divLoading").show();
            },
            complete: function () {
                $("#divLoading").hide();
            },
            success: function (data) {
                var arr = data;
                window.open(data.page, "_top");
            },
            error: function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    alert('Internal error: ' + jqXHR.responseText);
                } else {
                    alert('Unexpected ' + textStatus);
                }
            }

        });
        return;

    }
    $scope.confirmMailtoMemberReview = function (action) {

        if (action == 'submit') {
            //Please confirm to send the information to the member team for review. 
            $scope.Action_Msg_Header = 'Confirm send email to member review';
            $scope.Action_Msg_Detail = '';
            $('#modalMsg2').modal('show');

        }
        else if (action == 'yes') {


            var user_name = $scope.user_name;
            var token_doc = $scope.data_header[0].seq;

            $.ajax({
                url: url_ws + "Flow/set_email_member_review_stamp",
                data: '{"user_name":"' + user_name + '","token_doc":"' + token_doc + '"}',
                type: "POST", contentType: "application/json; charset=utf-8", dataType: "json",
                beforeSend: function () {
                    $("#divLoading").show();
                },
                complete: function () {
                    $("#divLoading").hide();
                },
                success: function (data) {
                    var arr = data;

                    if (arr[0].status == 'true') {
                        //ACTION_TO_REVIEW
                        var icount = $scope.data_session.length - 1;
                        $scope.data_session[icount].action_to_review = 1;
                        
                        check_case_member_review();
                        apply();
                        

                        $('#modalMsg2').modal('hide');
                    }

                },
                error: function (jqXHR, textStatus, errorThrown) {
                    if (jqXHR.status == 500) {
                        alert('Internal error: ' + jqXHR.responseText);
                    } else {
                        alert('Unexpected ' + textStatus);
                    }
                }

            });
        }

    }
    $scope.confirmCancle = function () {
        $scope.Action_Msg_Confirm = true;

        set_alert_confirm('Confirm canceling the PHA No.', '');
    }
    $scope.confirmSave = function (action) {


        //call function confirm ให้เลือก Ok หรือ Cancle  
        if (action == 'confirm_submit') {
            $scope.Action_Msg_Confirm = true;
            action = 'submit';
            $('#modalSendMail').modal('hide');
        } else if (action == 'confirm_submit_without') {
            $scope.Action_Msg_Confirm = true;
            action = 'submit_without';
            $('#modalSendMail').modal('hide');
            //$('#modalMsg').modal('hide');
            //return;
        } else {
            if (action == 'save') {

            } else {
                $scope.Action_Msg_Confirm = false;
                if ($scope.flow_role_type == 'admin') {
                    $('#modalSendMail').modal('show');
                    return;
                }
            }

        }

        //check required field 
        var pha_status = $scope.data_header[0].pha_status;
        //11	DF	Draft
        //12	WP	Waiting PHA Conduct
        //13	PC	PHA Conduct
        //21	WA	Waiting Approve Review
        //22	AR	Approve Reject
        //14	WF	Waiting Follow Up
        //15	WR	Waiting Review Follow Up
        //91	CL	Closed
        //81	CN	Cancle
        if (action == 'submit' || action == 'submit_without') {
            $('#modalMsg').modal('hide');
            $("#divLoading").hide();

            if ($scope.Action_Msg_Confirm == true) {
                var arr_chk = $scope.data_general;

                try {
                    if (pha_status == "11") {
                        if (arr_chk[0].expense_type == '' || arr_chk[0].expense_type == null) { set_alert('Warning', 'Please select a valid Expense Type'); return; }
                        if (arr_chk[0].sub_expense_type == '' || arr_chk[0].sub_expense_type == null) { set_alert('Warning', 'Please select a valid Sub-Expense Type'); return; }
                        if (arr_chk[0].id_apu == '' || arr_chk[0].id_apu == null) { set_alert('Warning', 'Please select a valid Area Process Unit'); return; }
                        if (arr_chk[0].functional_location == '' || arr_chk[0].functional_location == null) { set_alert('Warning', 'Please select a valid Functional Location'); return; }


                        arr_chk = $scope.data_memberteam;
                        if (arr_chk.length == 0) { set_alert('Warning', 'Please provide a valid Session List'); return; }
                        else {
                            var irows_last = arr_chk.length - 1;
                            if (arr_chk[irows_last].user_name == null) { set_alert('Warning', 'Please provide a valid Session List'); return; }
                        }

                    }
                    else if (pha_status == "12") {
                        if (arr_chk[0].expense_type == '' || arr_chk[0].expense_type == null) { set_alert('Warning', 'Please select a valid Expense Type'); return; }
                        if (arr_chk[0].sub_expense_type == '' || arr_chk[0].sub_expense_type == null) { set_alert('Warning', 'Please select a valid Sub-Expense Type'); return; }
                        if (arr_chk[0].id_apu == '' || arr_chk[0].id_apu == null) { set_alert('Warning', 'Please select a valid Area Process Unit'); return; }
                        if (arr_chk[0].functional_location == '' || arr_chk[0].functional_location == null) { set_alert('Warning', 'Please select a valid Functional Location'); return; }

                        arr_chk = $scope.data_drawing;
                        if (arr_chk.length == 0) { set_alert('Warning', 'Please provide a valid Drawing List'); return; }

                        arr_chk = $scope.data_memberteam;
                        if (arr_chk.length == 0) { set_alert('Warning', 'Please provide a valid Session List'); return; }
                        else {
                            var irows_last = arr_chk.length - 1;
                            if (arr_chk[irows_last].user_name == null) { set_alert('Warning', 'Please provide a valid Session List'); return; }
                        }

                        arr_chk = $scope.data_listworksheet;
                        if (arr_chk.length == 0) { set_alert('Warning', 'Please provide a valid List'); return; }
                        for (var i = 0; i < arr_chk.length; i++) {
                            if (arr_chk[i].causes == '' || arr_chk[i].causes == null) { set_alert('Warning', 'Please provide a valid causes'); return; }
                            if (arr_chk[i].consequences == '' || arr_chk[i].consequences == null) { set_alert('Warning', 'Please provide a valid Consequences'); return; }
                            if (arr_chk[i].responder_user_name == '' || arr_chk[i].responder_user_name == null) { set_alert('Warning', 'Please provide a valid Responder'); return; }
                        }
                    }
                    else if (pha_status == "21") {

                        $scope.data_header[0].approve_status = ($scope.selectSendBack == 'option2' ? 'approve' : 'reject');
                        if ($scope.selectSendBack == 'option2' && action == 'submit') {
                            if ($scope.data_header[0].approve_comment == '' || $scope.data_header[0].approve_comment == null
                                || $scope.data_header[0].approve_comment == undefined) {
                                set_alert('Warning', 'Please enter your comment'); return;
                            }
                        }

                    }

                    if ($scope.flow_role_type == 'admin') {
                        //mail noti
                        $('#modalSendMail').modal('show');
                    }

                } catch { }
            }

        } else if (action == 'save') {
            var arr_chk = $scope.data_general;
            if (pha_status == "11") {
                if (arr_chk[0].expense_type == '' || arr_chk[0].expense_type == null) { set_alert('Warning', 'Please select a valid Expense Type'); return; }
                if (arr_chk[0].sub_expense_type == '' || arr_chk[0].sub_expense_type == null) { set_alert('Warning', 'Please select a valid Sub-Expense Type'); return; }
                if (arr_chk[0].id_apu == '' || arr_chk[0].id_apu == null) { set_alert('Warning', 'Please select a valid Area Process Unit'); return; }
                if (arr_chk[0].functional_location == '' || arr_chk[0].functional_location == null) { set_alert('Warning', 'Please select a valid Functional Location'); return; }
            }
        }
        else {
            action = 'cancel'
        }

        save_data_create(action);

    }

    $scope.confirmSubmit = function (action) {
        $scope.Action_Msg_Confirm = false;
        if (action == 'no') {
            $('#modalMsg').modal('hide');
            return;
        }
        save_data_create("submit");
    }
    function check_data_general() {
        //แปลง date to yyyyMMdd
        //แปลง time to hh:mm
        try {
            $scope.data_general[0].target_start_date = $scope.data_general[0].target_start_date.toISOString().split('T')[0];
        } catch { }
        try {
            $scope.data_general[0].target_end_date = $scope.data_general[0].target_end_date.toISOString().split('T')[0];
        } catch { }
        try {
            $scope.data_general[0].actual_start_date = $scope.data_general[0].actual_start_date.toISOString().split('T')[0];
        } catch { }
        try {
            $scope.data_general[0].actual_end_date = $scope.data_general[0].actual_end_date.toISOString().split('T')[0];
        } catch { }
    }
    function check_master_ram() {
        // return angular.toJson($scope.master_ram);
        var arr_active = [];
        angular.copy($scope.master_ram, arr_active);
        var arr_json = $filter('filter')(arr_active, function (item) {
            return ((item.action_type == 'update' && item.action_change == 1) || item.action_type == 'insert');
        });
        return angular.toJson(arr_json);
    }
    function check_data_functional_audition() {
        //functional_location_audition
        var pha_seq = $scope.data_header[0].seq;
        var functional_audition_arr = $scope.data_general[0].functional_location_audition;
        var functional_audition_text = '';
        //var xSplitFunc = (functional_audition).replaceAll('"', '').replace('[', '').replace(']', '').split(",");
        for (var i = 0; i < functional_audition_arr.length; i++) {

            if (functional_audition_text != '') { functional_audition_text += ','; }
            if (functional_audition_arr[i] != '') {
                functional_audition_text += functional_audition_arr[i];
            }

        }

        $scope.data_functional_audition[0].seq = pha_seq;
        $scope.data_functional_audition[0].id = pha_seq;
        $scope.data_functional_audition[0].id_pha = pha_seq;
        $scope.data_functional_audition[0].functional_location = functional_audition_text;

        var arr_active = [];
        angular.copy($scope.data_functional_audition, arr_active);
        var arr_json = $filter('filter')(arr_active, function (item) {
            return (true);
        });

        return angular.toJson(arr_json);
    }
    function check_data_session() {

        var pha_seq = $scope.data_header[0].seq;
        for (var i = 0; i < $scope.data_session.length; i++) {
            $scope.data_session[i].id = $scope.data_session[i].seq;
            $scope.data_session[i].id_pha = pha_seq;
            try {
                $scope.data_session[0].meeting_date = $scope.data_session[0].meeting_date.toISOString().split('T')[0];
            } catch { }
        }

        var arr_active = [];
        angular.copy($scope.data_session, arr_active);
        var arr_json = $filter('filter')(arr_active, function (item) {
            return ((item.action_type == 'update' && item.action_change == 1) || item.action_type == 'insert');
        });
        for (var i = 0; i < $scope.data_session_delete.length; i++) {
            $scope.data_session_delete[i].action_type = 'delete';
            arr_json.push($scope.data_session_delete[i]);
        }
        return angular.toJson(arr_json);
    }
    function check_data_memberteam() {

        var pha_seq = $scope.data_header[0].seq;
        for (var i = 0; i < $scope.data_memberteam.length; i++) {
            $scope.data_memberteam[i].id = $scope.data_memberteam[i].seq;
            $scope.data_memberteam[i].id_pha = pha_seq;
            $scope.data_memberteam[i].no = (i + 1);
        }

        var arr_active = [];
        angular.copy($scope.data_memberteam, arr_active);
        var arr_json = $filter('filter')(arr_active, function (item) {
            return ((!(item.user_name == null) && item.action_type == 'update' && item.action_change == 1) || item.action_type == 'insert');
        });
        for (var i = 0; i < $scope.data_memberteam_delete.length; i++) {
            $scope.data_memberteam_delete[i].action_type = 'delete';
            arr_json.push($scope.data_memberteam_delete[i]);
        } 
        for (var i = 0; i < arr_active.length; i++) {
            if (arr_active[i].user_name == null) {
                arr_active[i].action_type = 'delete';
                arr_json.push(arr_active[i]);
            }
        }
         
        //check จากข้อมูลเดิมที่เคยบันทึกไว้ถ้าไม่มีในของเดิมให้ delete ออกด้วย
        for (var i = 0; i < $scope.data_memberteam.length; i++) {
            var arr_check = $filter('filter')($scope.data_memberteam_old, function (item) {
                return (item.user_name == $scope.data_memberteam[i].user_name );
            }); 
            if (arr_check.length == 0) {
                for (var l = 0; l < arr_check.length; l++) {
                    arr_check[l].action_type = 'delete';
                    arr_json.push(arr_check[l]);
                } 
            }
        }

        //check จากข้อมูล session ให้ delete ออกด้วย
        for (var i = 0; i < $scope.data_memberteam.length; i++) {
            var arr_check = $filter('filter')($scope.data_session, function (item) {
                return (item.seq == $scope.data_memberteam[i].id_session || item.id == $scope.data_memberteam[i].id_session);
            });
            if (arr_check.length == 0) {
                for (var l = 0; l < arr_check.length; l++) {
                    arr_check[l].action_type = 'delete';
                    arr_json.push(arr_check[l]);
                } 
            }
        }
        return angular.toJson(arr_json);
    }
    function check_data_drawing() {

        var pha_seq = $scope.data_header[0].seq;
        for (var i = 0; i < $scope.data_drawing.length; i++) {
            $scope.data_drawing[i].id = Number($scope.data_drawing[i].seq);
            $scope.data_drawing[i].id_pha = pha_seq;
        }

        var arr_active = [];
        angular.copy($scope.data_drawing, arr_active);
        var arr_json = $filter('filter')(arr_active, function (item) {
            return ((item.action_type == 'update' && item.action_change == 1) || item.action_type == 'insert');
        });
        for (var i = 0; i < $scope.data_drawing_delete.length; i++) {
            $scope.data_drawing_delete[i].action_type = 'delete';
            arr_json.push($scope.data_drawing_delete[i]);
        }
        alert(1);
        return angular.toJson(arr_json);
    }
    function check_data_listworksheet() {

        var pha_status = $scope.data_header[0].pha_status;
        var pha_seq = $scope.data_header[0].seq;

        //if (pha_status == 11 && $scope.data_general[0].sub_expense_type == 'Normal') {
        //    //check กรณีที่เปลี่ยนจาก Study เป็น Normal
        //    if ($scope.data_listworksheet.length > 0) {
        //        //ต้องลบออกเนื่องจาก ยังไม่ถึงขั้นตอน
        //    }
        //}

        for (var i = 0; i < $scope.data_listworksheet.length; i++) {
            $scope.data_listworksheet[i].id = Number($scope.data_listworksheet[i].seq);
            $scope.data_listworksheet[i].id_pha = pha_seq;

            //ram_action_security, ram_action_likelihood, ram_action_risk, estimated_start_date, estimated_end_date, document_file_path, document_file_name, action_status, responder_action_type, responder_user_name, responder_user_displayname
            try {
                var date_value = $scope.data_listworksheet[i].estimated_start_date.toISOString().split('T');
                if (date_value.length > 0) { $scope.data_listworksheet[i].estimated_start_date = date_value[0]; }
            } catch { }
            try {
                var date_value = $scope.data_listworksheet[i].estimated_end_date.toISOString().split('T');
                if (date_value.length > 0) { $scope.data_listworksheet[i].estimated_end_date = date_value[0]; }
            } catch { }
        }

        var arr_active = [];
        angular.copy($scope.data_listworksheet, arr_active);
        var arr_json = $filter('filter')(arr_active, function (item) {
            return ((item.action_type == 'update' && item.action_change == 1) || item.action_type == 'insert');
        });
        for (var i = 0; i < $scope.data_listworksheet_delete.length; i++) {
            $scope.data_listworksheet_delete[i].action_type = 'delete';
            arr_json.push($scope.data_listworksheet_delete[i]);
        }

        return angular.toJson(arr_json);
    }

    function check_data_ram_level() {

        //return angular.toJson($scope.master_ram_level);
        var arr_active = [];
        angular.copy($scope.master_ram_level, arr_active);
        var arr_json = $filter('filter')(arr_active, function (item) {
            return ((item.action_type == 'update' && item.action_change == 1) || item.action_type == 'insert');
        });
        return angular.toJson(arr_json);
    }

    function set_alert(header, detail) {

        $scope.Action_Msg_Header = header;
        $scope.Action_Msg_Detail = detail;
        $('#modalMsg').modal('show');
    }
    function set_alert_confirm(header, detail) {

        $scope.Action_Msg_Confirm = true;

        $scope.Action_Msg_Header = header;
        $scope.Action_Msg_Detail = detail;

        $('#modalMsg').modal('show');
    }



    //start Update Action Type null to Update 
    $scope.actionChange = function (_arr, _seq, type_text) {

        action_type_changed(_arr, _seq);

        var arr_submit = $filter('filter')($scope.data_task, function (item) {
            return ((item.action_type !== '' || item.action_type !== null));
        });

        if (arr_submit.length > 0) { $scope.submit_type = true; } else { $scope.submit_type = false; }

        if (type_text == "ChangeRAM") {
            console.log($scope.master_ram_level);
            set_master_ram_likelihood(_arr.id_ram);
        }

        if (type_text == "task") {
            $scope.selectedItemTaskView = _seq;
        }
        apply();
    }

    $scope.actionChangeTaskDrawing = function (_arr, _seq) {
        action_type_changed(_arr, _seq);

        var arr_submit = $filter('filter')($scope.data_task, function (item) {
            return ((item.action_type !== '' || item.action_type !== null));
        });
        if (arr_submit.length > 0) { $scope.submit_type = true; } else { $scope.submit_type = false; }

        if ($scope.data_taskdrawing) {
            var arr_drawing = $filter('filter')($scope.data_taskdrawing, function (item) {
                return ((item.id_list == _seq));
            });
            if (!arr_drawing) { return; }
            var _arr_drawing = arr_drawing[0];
            if (_arr_drawing.action_type == '') {
                _arr_drawing.action_type = 'update';
                _arr_drawing.action_change = 1;
                _arr_drawing.update_by = $scope.user_name;
                apply();
            } else if (_arr_drawing.action_type == 'update') {
                _arr_drawing.action_change = 1;
                _arr_drawing.update_by = $scope.user_name;
                apply();
            }
        }
    }

    $scope.actionChangeWorksheet = function (_arr, _seq, type_text) {

        if (_arr.recommendations == null || _arr.recommendations == '') {
            if (_arr.recommendations_no == null || _arr.recommendations_no == '') {
                //recommendations != '' ให้ running action no  
                var arr_copy_def = angular.copy($scope.data_listworksheet, arr_copy_def);
                arr_copy_def.sort((a, b) => Number(b.recommendations_no) - Number(a.recommendations_no));
                var recommendations_no = Number(Number(arr_copy_def[0].recommendations_no) + 1);
                _arr.recommendations_no = recommendations_no;
            }
        }
        action_type_changed(_arr, _seq);

        var arr_submit = $filter('filter')($scope.data_listworksheet, function (item) {
            return ((item.action_type !== '' || item.action_type !== null));
        });

        if (arr_submit.length > 0) { $scope.submit_type = true; } else { $scope.submit_type = false; }

    }
    function action_type_changed(_arr, _seq) {
        if (_seq == undefined) { _seq = 1; }
        if (_arr.seq == _seq && _arr.action_type == '') {
            _arr.action_type = 'update';
            _arr.update_by = $scope.user_name;
            apply();
        } else if (_arr.seq == _seq && _arr.action_type == 'update') {
            _arr.action_change = 1;
            _arr.update_by = $scope.user_name;
            apply();
        }
    }

    //start functioin show history data ของแต่ละ field
    $scope.filteredArr = [{ name: '', isActive: true }];
    $scope.filteredResults = [];
    $scope.showResults = false;
    $scope.filterResultGeneral = function (fieldText, fieldName) {
        $scope.filteredResults = [];
        var arr = [];
        if (fieldName == 'pha_request_name') {
            arr = $scope.data_all.his_pha_request_name;
        }
        else if (fieldName == 'descriptions') {
            //arr = $scope.data_all.his_descriptions;
        }
        else if (fieldName == 'task') {
            arr = $scope.data_all.his_task;
        }
        else if (fieldName == 'design_intent') {
            arr = $scope.data_all.his_design_intent;
        }
        else if (fieldName == 'design_conditions') {
            arr = $scope.data_all.his_design_conditions;
        }
        else if (fieldName == 'operating_conditions') {
            arr = $scope.data_all.his_operating_conditions;
        }
        else if (fieldName == 'task_boundary') {
            arr = $scope.data_all.his_task_boundary;
        }
        else if (fieldName == 'list') {
            arr = $scope.data_all.his_list;
        }
        else if (fieldName == 'listsub') {
            arr = $scope.data_all.his_listsub;
        }
        else if (fieldName == 'causes') {
            arr = $scope.data_all.his_causes;
        }
        else if (fieldName == 'consequences') {
            arr = $scope.data_all.his_consequences;
        }
        else if (fieldName == 'safeguards') {
            arr = $scope.data_all.his_safeguards;
        }
        else if (fieldName == 'recommendations') {
            arr = $scope.data_all.his_recommendations;
        }

        for (var i = 0; i < arr.length; i++) {
            var result = arr[i];
            if (result.name.toLowerCase().startsWith(fieldText.toLowerCase())) {
                $scope.filteredResults.push({ "field": fieldName, "name": result.name });
            }
        }

        $scope.showResults = $scope.filteredResults.length > 0;

        if ($scope.data_general[0].action_type == '') {
            action_type_changed($scope.data_general, $scope.data_general[0].seq);
        }
    };

    $scope.filterResultHistory = function (fieldText, fieldName, fieldID) {
        //if (fieldText.length < 3) { return; }

        $scope.filteredArr[0].fieldID = null;
        $scope.filteredResults = [];
        var arr = [];
        if (fieldName == 'pha_request_name') {
            arr = $scope.data_all.his_pha_request_name;
        }
        else if (fieldName == 'descriptions') {
            //arr = $scope.data_all.his_descriptions;
        }
        else if (fieldName == 'task') {
            arr = $scope.data_all.his_task;
        }
        else if (fieldName == 'design_intent') {
            arr = $scope.data_all.his_design_intent;
        }
        else if (fieldName == 'design_conditions') {
            arr = $scope.data_all.his_design_conditions;
        }
        else if (fieldName == 'operating_conditions') {
            arr = $scope.data_all.his_operating_conditions;
        }
        else if (fieldName == 'task_boundary') {
            arr = $scope.data_all.his_task_boundary;
        }
        else if (fieldName == 'list') {
            arr = $scope.data_all.his_list;
        }
        else if (fieldName == 'listsub') {
            arr = $scope.data_all.his_listsub;
        }
        else if (fieldName == 'causes') {
            arr = $scope.data_all.his_causes;
        }
        else if (fieldName == 'consequences') {
            arr = $scope.data_all.his_consequences;
        }
        else if (fieldName == 'safeguards') {
            arr = $scope.data_all.his_safeguards;
        }
        else if (fieldName == 'recommendations') {
            arr = $scope.data_all.his_recommendations;
        }

        try {
            for (var i = 0; i < arr.length; i++) {
                var result = arr[i];
                if (result.name.toLowerCase().includes(fieldText.toLowerCase())) {
                    $scope.filteredResults.push({ "field": fieldName, "name": result.name });
                }
            }
            $scope.showResults = $scope.filteredResults.length > 0;
            $scope.filteredArr = [{ "fieldID": ($scope.showResults == true ? fieldID : '') }];
        } catch { }
    };

    $scope.selectResult = function (result, items_ref, fieldName) {
        items_ref[fieldName] = result.name;
        $scope.filteredResults = [];
        $scope.showResults = false;
    };

    $scope.searchtext = function () {
        $scope.filteredData = $scope.followData.filter(function (item) {
            return item.file.includes($scope.searchdata) || item.id.includes($scope.searchdata);
        });
    };


    $scope.fillTextbox = function (string) {
        $scope.members = string;
        $scope.hidethis = true;
    }
    //end functioin show history data ของแต่ละ field

    // <==== start Popup Employee ของ Member team==== >
    $scope.filteredData = [];
    $scope.selectedData = {};
    $scope.updateSelectedItems = function () {
        $scope.selectedData = $scope.employeelist.filter(function (item) {
            return item.selected;
        });
    };
    $scope.selectedItems = function (item) {
        $scope.selectedData = item;
    };
    // <==== end Popup Employee ของ Member team==== >

    $(document).ready(function () {

    });

    page_load();

});


/*"listworksheet": [
    {
      "seq": 1,
      "id_pha": 55,
      "id": 1,
      "id_list": 1,
      "seq_list": 1,
      "seq_list_system": null,
      "seq_list_sub_system": null,
      "seq_causes": null,
      "seq_consequences": null,
      "seq_cat": null,
      "row_type": "list_system",
      "no": 1,
      "list_system_no": null,
      "list_system": null,
      "list_sub_system_no": null,
      "list_sub_system": null,
      "causes_no": null,
      "causes": null,
      "consequences_no": null,
      "consequences": null,
      "category_no": null,
      "category_type": null,
      "ram_befor_security": null,
      "ram_befor_likelihood": null,
      "ram_befor_risk": null,
      "major_accident_event": null,
      "safety_critical_equipment": null,
      "existing_safeguards": null,
      "ram_after_security": null,
      "ram_after_likelihood": null,
      "ram_after_risk": null,
      "recommendations_no": null,
      "recommendations": null,
      "safety_critical_equipment_tag": null,
      "responder_user_name": null,
      "responder_user_displayname": null,
      "estimated_start_date": null,
      "estimated_end_date": null,
      "action_status": "Open",
      "document_file_path": null,
      "document_file_name": null,
      "ram_risk_after_action": null,
      "ram_after_risk_action": null,
      "ram_action_security": null,
      "ram_action_likelihood": null,
      "ram_action_risk": null,
      "responder_action_type": null,
      "responder_action_date": null,
      "responder_receivesd_date": null,
      "responder_comment": null,
      "create_date": null,
      "update_date": null,
      "create_by": "string",
      "update_by": null,
      "no1": null,
      "action_type": "new",
      "action_change": 0,
      "seq_list1": null,
      "responder_user_id": null,
      "responder_user_email": null,
      "responder_user_img": null,
      "node_no": null
    }
  ],*/